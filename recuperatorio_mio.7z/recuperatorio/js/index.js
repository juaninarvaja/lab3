var xml = new XMLHttpRequest;
var url = "http://localhost:3000/";
var api = "";
var metodo = "GET";
var trClickeado;
var idGlobal;
var estadoNuevo;

$(document).ready(function(){
    MostrarSpiner(true);
    $.get("http://localhost:3000/personajes",
    function(data, status){
        var JsonRespuesta = data;
        datosToGrilla(JsonRespuesta);
        MostrarSpiner(false);
        console.log(JsonRespuesta);

        $("#btnCerrar").click(function()
        {
        MostrarModificar(false);
        });
        $("#btnGuardar").click(function()
        {
            clickModificar();
        });
        $("#btnEliminar").click(function()
        {
            clickEliminar();
        });
        $("input").change(function(e){
            //console.log(e.delegateTarget.id);
            //console.log(e.previosElementSibling)
            idGlobal = e.delegateTarget.id;
            var objJson = tomarDatosFila(e.delegateTarget.id,e.delegateTarget.files[0].name);
            MostrarSpiner(true);
            $.ajax({
                url : "http://localhost:3000/editarFoto",
                data : objJson,
                type : 'POST',
                success : function(data, status){          
                    if (e.delegateTarget.files && e.delegateTarget.files[0]) 
                    {
                    
                    var fReader= new FileReader();
                                    
                      fReader.addEventListener("load", function(e) {
                            //console.log(e.target.result);
                            var string = "#imagen" +idGlobal;
                            $(string).attr("src",e.target.result);
                            }); 
                                    
                     fReader.readAsDataURL(e.delegateTarget.files[0]);
                      }
                    MostrarSpiner(false);
                },
                error : function(xhr, status) {
                    alert('Disculpe, existió un problema');
                },
                complete : function(xhr, status) {

                }
            });
            });
            $("select").change(function(e)
            {
                //console.log("entro!" + e.delegateTarget.innerText);
                idGlobal = e.delegateTarget.id;
                estadoNuevo = e.delegateTarget.value;
                var objJson = tomarDatosEstado(e.delegateTarget.id,e.delegateTarget.value);
                MostrarSpiner(true);
                $.ajax({
                    url : "http://localhost:3000/editarEstado",
                    data : objJson,
                    type : 'POST',
                    success : function(data, status){          
                    
                        
                  
                                var string = "#estado" +idGlobal;
                                $(string).attr("value",estadoNuevo);
                                console.log(data);

                                        
                         //fReader.readAsDataURL(e.delegateTarget.value);
                          
                        MostrarSpiner(false);
                    },
                    error : function(xhr, status) {
                        alert('Disculpe, existió un problema');
                    },
                    complete : function(xhr, status) {
    
                    }
            } );
        });
            
    })
});
function tomarDatosEstado(id,estado)
{
    var stringEstado = "";
    if(estado == 1)
    {
    stringEstado = "Vivo";
    }
    else
    {
        stringEstado = "Muerto";
    }
    var ObjJson ={
        "id":id,
        "estado":stringEstado
    }
    return ObjJson;
}
function tomarDatosFila(id,foto)
{
    var ObjJson ={
        "id":id,
        "imagen":foto
    }
    return ObjJson;
}

//#region cargarGrilla
function datosToGrilla(arrayJson)
{
    for(var i = 0; i<arrayJson.length; i++){
        agregarTr(arrayJson[i]);
    }
}

function agregarTr(tr)
{
 var filaDOM = crearElementoTr(tr);
 //filaDOM.addEventListener("dblclick",filaDobleClick);
 var tbody = document.getElementById("bodyTabla");
    tbody.appendChild(filaDOM);
}
function crearElementoTr(arrayDatosFila)
{
    var r = document.createElement("tr");
    //r.setAttribute("indentificador", arrayDatosFila["id"]);  
    var indexName = Object.keys(arrayDatosFila);
   // var dato = arrayDatosFila[indexName[5]];
    r.appendChild(crearElementoImg(arrayDatosFila));
    
    var dato = arrayDatosFila[indexName[1]];  
    r.appendChild(crearElementoTd(dato));
     dato = arrayDatosFila[indexName[2]];  
    r.appendChild(crearElementoTd(dato));

     dato = arrayDatosFila[indexName[4]];
    r.appendChild(crearElementoSelect(arrayDatosFila));
    var stringId = "fila"+arrayDatosFila[indexName[0]]
    r.setAttribute("id",stringId);
    
    return r;
}

function crearElementoTd(dato)
{
    var d = document.createElement("td");
    var txt = document.createTextNode(dato);
    d.appendChild(txt);
    return d;
}
function crearElementoImg(arrayDatosFila)
{
    var indexName = Object.keys(arrayDatosFila);
    var d = document.createElement("td");
     var myImage = new Image(80,80);
     myImage.src = arrayDatosFila[indexName[5]];
 
    myImage.height = 80;
    myImage.width= 80;
    var stringId = "imagen"+arrayDatosFila[indexName[0]]
    myImage.setAttribute("id",stringId);

    
    d.appendChild(myImage);
     var input = document.createElement('input');
     input.type = "file";
     input.accept= "image/png, image/jpeg";
     var stringId =arrayDatosFila[indexName[0]]
     input.setAttribute("id",stringId);
     console.log(stringId);
     d.appendChild(input);


    return d;
}
function crearElementoSelect(arrayDatosFila)
{
    var indexName = Object.keys(arrayDatosFila);
    var d = document.createElement("td");
    var s = document.createElement("SELECT");
    // var txt = document.createTextNode(dato);
    // s.appendChild(txt);
    var stringId =arrayDatosFila[indexName[0]]
    s.setAttribute("id",stringId);
    var opcionDefault = document.createElement("option");
    dato = arrayDatosFila[indexName[4]];
    opcionDefault.text =arrayDatosFila[indexName[4]];
    
    if(opcionDefault.text == "Vivo")
    {
        opcionDefault.value = 1;
    }
    else{
        opcionDefault.value = 2;
    }
    s.add(opcionDefault);
    s.size = 1;

    if(dato=="Vivo")
    {
        var opcion2 = document.createElement("option");
        opcion2.text = "Muerto";
        opcion2.value = 2;
        s.add(opcion2);
        
    
    }
    else
    {
        var opcion = document.createElement("option");
        opcion.text = "Vivo";
        opcion.value =1;
        s.add(opcion);
      
    }


    d.appendChild(s);

    return d;
}
function TrToJson(tr){

    var hijos = tr.children;
    var ObjJson ={
        "id":hijos[0].innerText,
        "nombre":hijos[1].innerText,
        "cuatrimestre":hijos[2].innerText,
        "fechaFinal":hijos[3].innerText,
        "turno":hijos[4].innerText}
    return ObjJson;
}
function MostrarSpiner(valor)
{
    $("#load").attr("hidden",!(valor));
}
