
   // console.log("Send terminado"); //imprime directamente aunque no se termine de mandar la informacion (asincrona), sigue funcionando
   var xml = new XMLHttpRequest(); 
   window.addEventListener("load",function()
    {
        var btn= $("btn");
        //btn.addEventListener("click",enviarGet);
        btn.addEventListener("click",enviarPost);
    });
    function callback()
    {
        if(xml.readyState===4)
         {
             if(xml.status===200)
             {
                var respuesta = xml.responseText;
                if(respuesta=="true")
                {
                  alert("login OK");
                 }else if(respuesta=="false")
                {
                  alert("login incorrecta");
                }else
                {
                   alert(respuesta);
                 }
                }
        else
         {
               alert("Error del servidor");
            }
        }
            

    }
function enviarGet()
    {
        var usr = $("usr");
        var pass = $("pass");

        if(usr.value !="" && pass.value != "")
        {
            var parametros = "?usr="+usr.value+"&"+"pass="+pass.value;
           // xml.open("GET","http://localhost:3000/loginUsuario"+parametros,true);
            xml.open("GET","http://localhost:3000/loginUsuario"+parametros,true);
       
            xml.onreadystatechange = callback; 
            xml.send();
           
        }

    }
    function enviarPost()
    {
        var usr = $("usr");
        var pass = $("pass");

        if(usr.value !="" && pass.value != "")
        {
            var parametros = "usr="+usr.value+"&"+"pass="+pass.value;
            xml.open("POST","http://localhost:3000/loginUsuario",true);
            xml.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            //ahora no viajan mas por url sino por el sen si es POST.
            //le tenemos q avisar al servidor como le estamos pasando la informacion (setREquesHeader)
            //si es GET esa linea no va
            xml.onreadystatechange = callback; 
            xml.send(parametros);
            
        }

    }

function $(id)
{
    return document.getElementById(id);
}