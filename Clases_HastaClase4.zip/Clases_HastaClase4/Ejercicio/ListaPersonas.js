window.addEventListener("load",function()
{
var btnGuardar = document.getElementById("btnGuardar");
btnGuardar.addEventListener("click",guardar);

var btnAgregar = document.getElementById("btnAgregar");
btnAgregar.addEventListener("click",abrir);

var btnCerrar = document.getElementById("btnCerrar");
btnCerrar.addEventListener("click",cerrar);

TraerDatosFila();

}); 

function abrir()
{
console.log("entroo!");
var contAgregar = document.getElementById("contenedor");
var btn = document.getElementById("btnAgregar");
contAgregar.hidden=false;
btn.hidden = true;



}
function cerrar()
{
    var contAgregar = document.getElementById("contenedor");
    var btn = document.getElementById("btnCerrar");
    var btnAgregar = document.getElementById("btnAgregar");
    document.getElementById("nombre").value = "";
    document.getElementById("apellido").value = "";
    btnAgregar.hidden = false;
    btn.hidden = false;
    contAgregar.hidden = true;

}
function guardar()
{
   var nombre= document.getElementById("nombre").value;
   var apellido = document.getElementById("apellido").value;
    if(apellido == "" || nombre == "")
    {
    document.getElementById("nombre").className = "error";
    document.getElementById("apellido").className = "error";
    alert("se necesita un nombre y un apellido");
    }
    else
    {
        if(confirm("seguro quiere cargar persona?")==true)
        {
            var tbody=  document.getElementById("tCuerpo"); //el bojeto no el valor
           // tbody.innerHTML += crearFila(nombre,apellido);
           document.getElementById("nombre").className = "sinError";
           document.getElementById("apellido").className = "sinError";
           console.log("entro al confir",tbody.innerHTML);
           
            tbody.innerHTML +=
            "<td>"+nombre+"</td>"+
            "<td>"+apellido+"</td>"
            "<td>" + "Borrar" + "</td>"; 
            
        }
    }

}

function crearFila(val1,val2)
{
var string = "<tr><td>"  + val1 + "</td> <td>"  + val2+ "</td> <td>"  + borrar+ "</td> </tr>"
return string;
}

 


