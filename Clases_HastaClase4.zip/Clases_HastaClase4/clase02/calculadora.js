
//window.addEventListener("load",inicio);
//sin paretnesis sumar porque es un puntero
 window.addEventListener("load",function()
 {
 var btnSumar = document.getElementById("btnSumar");
 //btnSumar.onclick funciona con un solo evento
 btnSumar.addEventListener("click",sumar);
 var btnGuardar = document.getElementById("btnSumaryGuardar");
 btnGuardar.addEventListener("click",guardar);
 }); //con este no gasto espacio en memoria pq la voy a usar una sola vez

function sumar() 
{
    var numeroUno = document.getElementById("numUno");
    var numeroDos = document.getElementById("numDos");
    var resul =  document.getElementById("numResultado");
    resul.value  = parseInt(numeroUno.value) + parseInt(numeroDos.value);
    
}

function guardar()
{
    sumar();
    var numeroUno = document.getElementById("numUno").value;
    var numeroDos = document.getElementById("numDos").value;
    var resul =  document.getElementById("numResultado").value;

    var tbody=  document.getElementById("tbody"); //el bojeto no el valor
    tbody.innerHTML += crearFila(numeroUno,numeroDos,resul);
}

 function crearFila(val1,val2,val3)
 {
 var string = "<tr><td>"  + val1 + "</td> <td>"  + val2+ "</td> <td>"  + val3+ "</td> </tr>"
 return string;
 }

