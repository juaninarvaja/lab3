var xml = new XMLHttpRequest;
var url = "http://localhost:3000/";
var api = "personas";
var metodo = "GET";

window.addEventListener("load", function(){
    getPersonas();
    
    var btnAgregar = document.getElementById("btnAgregar");
    
    btnAgregar.addEventListener("click", clickAgregar);
 
});

function datosToGrilla(arrayDatos){    
 for(var i = 0; i<arrayDatos.length; i++){
        agregarTr(arrayDatos[i]);
    }
}

// function agregarFila(arrayDatosFila){
//     var filaHtml = crearHtmlFila(arrayDatosFila);
//     var tbody = document.getElementById("bodyTabla");

//     tbody.innerHTML += filaHtml;
// }

function agregarTr(tr)
{
 var filaDOM = crearElementoTr(tr);
 var tbody = document.getElementById("bodyTabla");
    tbody.appendChild(filaDOM);
}

function crearElementoTr(arrayDatosFila)
{
    //var nuevoNodoElementoTr = document.createElement("tr");
    var r = document.createElement("tr");
    //var indexName = ["nombre","apellido","fecha","telefono"];
    var indexName = Object.keys(arrayDatosFila);
    for(var i = 0;i<indexName.length; i++)
    {
        var dato = arrayDatosFila[indexName[i]];
        r.appendChild(crearElementoTd(dato));
    }

    return r;
}

function crearElementoToLink(tdTxt)
{
    var td = document.createElement("td");
    var a = document.createElement("a");
    var txt = document.createTextNode(tdTxt);
    


}
function crearElementoTd(dato)
{
    var d = document.createElement("td");
    var txt = document.createTextNode(dato);
    d.appendChild(txt);
    return d;
}

// function crearHtmlFila(arrayDatosFila){
//     var filaHtml = "<tr><td>"+arrayDatosFila["nombre"]+
//     "</td><td>"+arrayDatosFila["apellido"]+
//     "</td><td>"+arrayDatosFila["fecha"]+
//     "</td><td>"+arrayDatosFila["telefono"]+"</td></tr>";
//     return filaHtml;
// }
// function crearGrilla(per) //funcion del profe
// {
// var tCuerpo = document.getElementById("tbody");
// var personas = JSON.parse(per);


//     for(var i=0;i<personas.length;i++)
//     {
//         var row = document.createElement("tr");
//         var obj = personas[i];
//         var colums = Object.keys(obj);

//         for(var j=0;j<colums.length;j++)
//         {
//             var cel = document.createElement("td");
//             var text = document.createTextNode(obj[colums[j]]);
//             cel.appendChild(text);
//             row.appendChild(cel);

//         }
//         var cel = document.createElement("td");
//         var link = document.createElement("a");
//         link.setAttribute("href","#");
//         var text = document.createTextNode("borrar");

//         link.appendChild(text);
//         cel.appendChild(link);
//         row.appendChild(cel);
        
//         tCuerpo.appendChild(row);
//     }


// }

function borrar(event)
{
    event.preventDefault();
    //console.log()
}

function clickAgregar(){
    mostrarFormulario(true);

    //resetearTxt();
}

 function mostrarFormulario(mostrar){
   var form = document.getElementById("formulario");
    var btnAgregar = document.getElementById("btnAgregar");

     form.hidden = !(mostrar);
    btnAgregar.hidden = mostrar;
 }

