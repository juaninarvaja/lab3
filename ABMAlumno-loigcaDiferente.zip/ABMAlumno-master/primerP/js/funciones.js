
var httpReq = new XMLHttpRequest();
var callBack = function () {
    console.log("LLego info del servidor." + httpReq.readyState);
    if (httpReq.readyState == 4) {
        console.log(httpReq.status);
        if (httpReq.status == 200) {
            console.log(httpReq.responseText);
            var respuesta = JSON.parse(httpReq.responseText);
            response(respuesta);
        } else {
            alert("Internal server error.");
        }
    }
}


function ingresarUsuario(){
    var email = $("#user").val();
    var password = $("#pass").val();

    var datosLogin = {
        email : email,
        password : password
    }    

    $.ajax({ //PETICION POST
                url: "http://localhost:3000/login",
                data: datosLogin,
                type: "POST",
                success: function (result) {
                    response(result);
                    console.log(result);
                }
            });

}


function response(respuesta){
    var email = $("#user").val();
    var password = $("#pass").val();
    var type = respuesta.type;

    if(type != "error"){
        var obj = {
            email : email,
            password :password,
            type : type
        }
        localStorage.setItem("values", JSON.stringify(obj));
        alert("Usuario "+email+" logueado correctamente.");
        window.location.replace("index.html");
    }
    if(type === "error"){
        $("#user").addClass("error");
        $("#pass").addClass("error");
        alert("Usuario o contraseña incorrectos!!");
    }

}


