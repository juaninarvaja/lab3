
var getNotas = localStorage.getItem("notas");
if (getNotas == null) {
    window.onload = pedirNotasGet;

}
else {
    console.log("Entro al else" + getNotas);
    window.onload = armarListaConLocalSt; //Armo la funcion para invocarla despues de armar el cuerpo HTML.
}

var httpReq = new XMLHttpRequest();

function armarListaConLocalSt() {
    armarLista(JSON.parse(getNotas));
}

function pedirNotasGet() {
    var parametros = "";
    var url = "http://localhost:3000/notas";
    var tipo = true;

    $.ajax({ //PETICION GET
        url: "http://localhost:3000/notas",
        success: function(result){
            var stringNotas = JSON.stringify(result);
            armarLista(result);
            localStorage.setItem("notas", JSON.stringify(result));
            console.log(result);
        }
    });   

}

function armarLista(notas) {
    var values = localStorage.getItem("values");
    values = JSON.parse(values);

    // alert(values.type);
    if (values.type === "Admin") {
            $("thead tr").append("<th>Acciones</th>");
        }

    var i;
    for (i = 0; i < notas.length; i++) {

            $("#tbody").append("<tr class='"+(notas[i].nota<4?'noAprobado':'')+"'><td>" + notas[i].nombre + "</td><td>" + notas[i].legajo + "</td><td>"
                + notas[i].materia + "</td><td>" + notas[i].nota + "</td>"
                +(values.type === "Admin"?"<td><a href='#' onClick='editar(" + i + ")'>Editar</a> | <a href='#' onClick='eliminar(" + i + ")'>Eliminar Nota</a></td></tr>":"</tr>"));
       

    }
   // $("tbody").innerHTML = cuerpo;
}

function mostrarDiv() {
    //alert("Agregar Persona");
    $("divPersona").hidden = false;
}

function eliminar(index){
    getNotas = localStorage.getItem("notas");
    var array = JSON.parse(getNotas);
    var id = array[index].id;

    var obj = {
        id : id,
    }
    var jsonString = JSON.stringify(obj);

    $.ajax({ //PETICION POST
        url: "http://localhost:3000/eliminarNota",
        data: obj,
        type: "POST",
        success: function (result) {
            response(result);
            console.log(result);
        }
    });
}


function editar(index) { //Implementar editar!!
    getNotas = localStorage.getItem("notas");
    var array = JSON.parse(getNotas);
    alert(array);
    $("#nombre").val(array[index].nombre);
    $("#materia").val(array[index].materia);
    $("#nota").val(array[index].nota);
    $("#legajo").val(array[index].legajo);
    $("#id").val(array[index].id);
    $("#edit").show();
    }

function editUser(){
    var nombre =  $("#nombre").val();
    var materia = $("#materia").val();
    var nota = $("#nota").val();
    var legajo = $("#legajo").val();
    var id =  $("#id").val();
    $("#edit").hide();

    var obj = {
        id : id,
        legajo: legajo,
        nombre: nombre,
        materia: materia,
        nota: nota
    }
    var jsonString = JSON.stringify(obj);
    console.log(jsonString);

    $.ajax({ //PETICION POST
        url: "http://localhost:3000/editarNota",
        data: obj,
        type: "POST",
        success: function (result) {
            response(result);
            console.log(result);
            armarListaConLocalSt();s
        }
    });

}

function response(respuesta){
    var type = respuesta.type;
    var msg = respuesta.message;

    if (type==="ok"){
        alert("Se ha editado correctamente!!");
        pedirNotasGet();
        location.reload();
    }
    else{
        $("#msgError").val(msg);
        $("#divError").show();
    }

}

function reload(){
    $("#divError").hide();
    pedirNotasGet();
    location.reload();

}





