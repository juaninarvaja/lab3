
namespace parcial
{
    $(document).ready(function() {
        $("#btnCancelar").click(Manejadora.limpiarFormulario);
        $("#btnGuardar").click(Manejadora.agregarEmpleado);
        $("#mostrar").click(Manejadora.mostrarEmpleados);
    });
    export class Manejadora
    {
        public static  agregarEmpleado():void
        {
            let nombre:string = String($("#nombre").val());
            let apellido:string = String($("#apellido").val());
            let edad:number = Number($("#edad").val());
            let legajo:number= Number($("#legajo").val());
            let turno:string = String($("#turno").val());
            // let apellido
            // let legajo 
            let unEmpleado:Empleado = new Empleado(nombre,apellido,edad,turno,legajo);
            console.log(unEmpleado);

            localStorage.setItem(String(unEmpleado.legajo),unEmpleado.personaToJson());
          
            
        }
        public static limpiarFormulario():void
        {

        }
        public static mostrarEmpleados():void
        {
            for(let i= 0; i < localStorage.length; i++)
            {
                let key:string = String(localStorage.key(i));
                console.log(localStorage.getItem(key));
            }
        }
        public modificar(i:number):void
        {

        }
        public static eliminar(i:number):void
        {
            localStorage.removeItem(String(i));

        }
        public filtrarPorHorario():void
        {

        }
        public promedioEdadPorHorario():void
        {

        }

    }
}