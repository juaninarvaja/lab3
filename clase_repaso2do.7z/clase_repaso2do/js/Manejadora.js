"use strict";
var parcial;
(function (parcial) {
    $(document).ready(function () {
        $("#btnCancelar").click(Manejadora.limpiarFormulario);
        $("#btnGuardar").click(Manejadora.agregarEmpleado);
        $("#mostrar").click(Manejadora.mostrarEmpleados);
    });
    var Manejadora = /** @class */ (function () {
        function Manejadora() {
        }
        Manejadora.agregarEmpleado = function () {
            var nombre = String($("#nombre").val());
            var apellido = String($("#apellido").val());
            var edad = Number($("#edad").val());
            var legajo = Number($("#legajo").val());
            var turno = String($("#turno").val());
            // let apellido
            // let legajo 
            var unEmpleado = new parcial.Empleado(nombre, apellido, edad, turno, legajo);
            console.log(unEmpleado);
            localStorage.setItem(String(unEmpleado.legajo), unEmpleado.personaToJson());
        };
        Manejadora.limpiarFormulario = function () {
        };
        Manejadora.mostrarEmpleados = function () {
            for (var i = 0; i < localStorage.length; i++) {
                var key = String(localStorage.key(i));
                console.log(localStorage.getItem(key));
            }
        };
        Manejadora.prototype.modificar = function (i) {
        };
        Manejadora.eliminar = function (i) {
            localStorage.removeItem(String(i));
        };
        Manejadora.prototype.filtrarPorHorario = function () {
        };
        Manejadora.prototype.promedioEdadPorHorario = function () {
        };
        return Manejadora;
    }());
    parcial.Manejadora = Manejadora;
})(parcial || (parcial = {}));
