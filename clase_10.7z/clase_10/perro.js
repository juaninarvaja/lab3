"use strict";
var animal;
(function (animal) {
    var Perro = /** @class */ (function () {
        function Perro(nombre) {
            this.nombre = ""; //asi adentro de calse, directamente el nuvel de visibilidad o nada
            if (nombre != undefined) {
                this.nombre = nombre;
            }
        }
        Perro.prototype.hacerRuido = function () {
            return "Guau!!";
        };
        Perro.prototype.getNombre = function () {
            return this.nombre;
        };
        Perro.prototype.setNombre = function (nombre) {
            this.nombre = nombre;
        };
        return Perro;
    }());
    animal.Perro = Perro;
})(animal || (animal = {}));
