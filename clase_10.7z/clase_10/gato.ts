namespace animal
{
export class Gato implements Animal
{

    private nombre:string=""; //asi adentro de calse, directamente el nuvel de visibilidad o nada
    constructor(nombre?:string)
    {
        if(nombre!= undefined)
        {
            this.nombre = nombre;
        }
    }
    getNombre():string
    {
        return this.nombre;
    }
    setNombre(nombre:string)
    {
        this.nombre = nombre;
    }
    
    hacerRuido():string //asi adentro de una clase 
    {
    return "Miau!!";
    }
}
}