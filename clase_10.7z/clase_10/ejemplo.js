"use strict";
var animal;
(function (animal) {
    $(document).ready(function () {
        $("#btnNuevo").click(agregar);
        $("#btnMostrar").click(mostrar);
    });
    function Saludar(mi) {
        console.log(mi.hacerRuido());
        //+  "---" +mi.getNombre();
    }
    animal.Saludar = Saludar;
    //var o let si estan afuera
    var lista = new Array();
    function agregar() {
        var nombre = String($("#nombre").val());
        var tipoMascota = Number($("#animal").val());
        if (nombre != null && nombre != "" && tipoMascota != NaN) {
            if (tipoMascota === 1) {
                lista.push(new animal.Perro());
            }
            else {
                lista.push(new animal.Gato());
            }
        }
    }
    animal.agregar = agregar;
    function modificar() { }
    animal.modificar = modificar;
    function eliminar() { }
    animal.eliminar = eliminar;
    function mostrar() {
        console.log("animales");
        lista.forEach(Saludar);
    }
    animal.mostrar = mostrar;
})(animal || (animal = {}));
