
namespace animal
{
export class Perro implements Animal{
    private nombre:string=""; //asi adentro de calse, directamente el nuvel de visibilidad o nada
    constructor(nombre?:string) //no existen las sobrecargas de contructores, tengo q poner parametros opcionales
    //que van con el signo de pregunta
    {
        if(nombre!= undefined)
        {
            this.nombre = nombre;
        }
    }

    hacerRuido():string //asi adentro de una clase 
    {
    return "Guau!!";
    }

    getNombre():string
    {
        return this.nombre;
    }
    setNombre(nombre:string)
    {
        this.nombre = nombre;
    }
}
}