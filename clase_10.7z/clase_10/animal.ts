
namespace animal
{

    export interface Animal 
    {
     hacerRuido():string;
    }
}
