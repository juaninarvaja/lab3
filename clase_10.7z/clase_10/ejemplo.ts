

namespace animal
{
    $(document).ready(function() {
        $("#btnNuevo").click(agregar);
        $("#btnMostrar").click(mostrar);
    });
     
    
export function Saludar(mi:Animal) //si estoy fuera de una clase necesito asi
{
    console.log(mi.hacerRuido());
    //+  "---" +mi.getNombre();
    
}
//var o let si estan afuera

let lista:Array<Animal> = new Array<Animal>();








export function agregar()
{
let nombre:string = String($("#nombre").val());
let tipoMascota:number = Number($("#animal").val());
if(nombre != null && nombre != "" &&  tipoMascota != NaN)
{
    if(tipoMascota === 1)
    {
        lista.push(new Perro());
    }
    else
    {
        lista.push(new Gato());
    }
}

}

export function modificar(){}

export function eliminar(){}

export function mostrar()
{
    console.log("animales");
    lista.forEach(Saludar);
}

}
