var xml = new XMLHttpRequest;
var url = "http://localhost:3000/materias";
var api = "";
var metodo = "GET";

window.addEventListener("load", function(){
    getPersonas();
    console.log("load");

    //   var selectFila =   document.getElementById("fila");
    //   selectFila.addEventListener("ondblclick",DobleClickGrilla);
    // var btnAgregar = document.getElementById("btnAgregar");
    // btnAgregar.addEventListener("click", clickAgregar);

    // var btnCerrar= document.getElementById("btnCerrar");
     //btnCerrar.addEventListener("click", clickCerrar);
    
    var btnCerrarM= document.getElementById("btnGuardar");
      btnCerrarM.addEventListener("click", clickModificar);


    //var btnGuardar = document.getElementById("btnGuardar");
    // btnGuardar.addEventListener("click", clickAgregarNuevo);

    //  var btnModificar = document.getElementById("btnGuardar");
    //  btnModificar.addEventListener("click", clickAgregarModificar);
});


function DobleClickGrilla()
{
    console.log("hizo doble click")
}



function datosToGrilla(arrayDatos){    
 for(var i = 0; i<arrayDatos.length; i++){
        agregarTr(arrayDatos[i]);
    }
}


//#region Manejo Nodos
function agregarTr(tr)
{
 var filaDOM = crearElementoTr(tr);
 var tbody = document.getElementById("bodyTabla");
    tbody.appendChild(filaDOM);
}

function crearElementoTr(arrayDatosFila)
{
    //var nuevoNodoElementoTr = document.createElement("tr");
    var r = document.createElement("tr");
    //var indexName = ["nombre","apellido","fecha","telefono"];
    var indexName = Object.keys(arrayDatosFila);
    for(var i = 0;i<indexName.length; i++)
    {
        var dato = arrayDatosFila[indexName[i]];
        r.appendChild(crearElementoTd(dato));
    }
    // r.setAttribute("id","fila");
    // var selectFila =   document.getElementById("fila");
    // selectFila.addEventListener("ondblclick",DobleClickGrilla);
    //r.appendChild(crearElementoToLinkBorrar("borrar"));
    r.appendChild(crearElementoToLinkModificar("modificar"));
    return r;
}

function clickModificar(event)
{
    event.preventDefault();
    var a = event.srcElement;
    var parent = a;
    
     while(parent.nodeName !== "TR"){        
           parent = parent.firstElementChild

         }
         var id = parent.firstElementChild;
         var nombre = id.nextElementSibling;
         var cuatrimestre= nombre.nextElementSibling;
         var fechaFinal= cuatrimestre.nextElementSibling;
         var turno = fechaFinal.nextElementSibling;

             nombre.innerText =$("nombreM").value 
             cuatrimestre.innerText = $("cuatrimestre").value;
             fechaFinal.innerText = $("fechaM").value;
             turno.innerText = $("turnoM").innerText;

}

//#region links
function crearElementoToLinkBorrar(tdTxt)
{
    var td = document.createElement("td");
    var a = document.createElement("a");
    var txt = document.createTextNode(tdTxt);
    
    a.setAttribute("href", "#");
    a.addEventListener("click", borrarFila);
    
    a.appendChild(txt);
    td.appendChild(a);

    return td;
}



function crearElementoToLinkModificar(tdTxt)
{
    var td = document.createElement("td");
    var a = document.createElement("a");
    var txt = document.createTextNode(tdTxt);
    
    a.setAttribute("href", "#");
    a.addEventListener("click", modificarFila);
    
    a.appendChild(txt);
    td.appendChild(a);

    return td;
}
//#endregion

function crearElementoTd(dato)
{
    var d = document.createElement("td");
    var txt = document.createTextNode(dato);
    d.appendChild(txt);
    return d;
}


//#endregion


//#region borrar y modificar
function borrarFila(event){    
    event.preventDefault();
    var a = event.srcElement;
    var parent = a;
    
    while(parent.nodeName !== "TR"){        
        parent = parent.parentNode;
        console.log(parent.nodeName);      
    }
    parent.parentNode.removeChild(parent);
}

function modificarFila(event){    
   
    event.preventDefault();
    var a = event.srcElement;
    var parent = a;
    
    while(parent.nodeName !== "TR"){        
        parent = parent.parentNode;
        if(parent.nodeName == "TR")
         {
        //console.log(parent.hasAttribute("nombre"));
        var id = parent.firstElementChild;
        var nombre = id.nextElementSibling;
        var cuatrimestre= nombre.nextElementSibling;
        var fechaFinal= cuatrimestre.nextElementSibling;
        var turno = fechaFinal.nextElementSibling;
        //falta verificar q no sean nulos en un if
         $("nombreM").value = nombre.innerText;
         if(turno.innerText == "Mañana")
         {
            $("m").checked = true;
         }
         if(turno.innerText == "Noche")
         {
            $("n").checked = true;
         }
         $("cuatrimestre").value = cuatrimestre.innerText;
         fechaParseada = Date.parse(fechaFinal.innerText);
         console.log(fechaParseada);
         $("fechaM").value = fechaParseada;
         //fechaFinal.innerText;
         
        
        // apellido.innerText =$("apellidoM").value 
        // fecha.innerText = $("fechaM").value;
        // numero.innerText = $("telefonoM").value;
        MostrarModificar();
      
  
         }
    }
    //parent.parentNode.removeChild(parent);
}
//#endregion




function clickAgregarNuevo(){
   
     var nombre = $("nombre");
     var apellido= $("apellido");
     var fecha = $("fecha");
     var telefono = $("telefono");
     var personaAux = {nombre:nombre.value,apellido:apellido.value,fecha:fecha.value,telefono:telefono.value};
     console.log(nombre.value);
     console.log(personaAux.nombre);
     agregarTr(personaAux);

}

 function $(elemento) {
    return document.getElementById(elemento);
}
//#region aparicion y desaparicion (hiddens)
function mostrarFormulario(mostrar){
    var form = document.getElementById("formulario");
   var btnAgregar = document.getElementById("btnAgregar");

    form.hidden = !(mostrar);
    btnAgregar.hidden = mostrar;
 }
 function clickCerrar(){
    //mostrarFormulario(false);
    var contAgregar = document.getElementById("contenedor");
    var btnC= document.getElementById("btnCerrar");
    var btnAgregar = document.getElementById("btnAgregar");
    //document.getElementById("nombre").value = "";
    //document.getElementById("apellido").value = "";
    btnAgregar.hidden = false;
    btnC.hidden = false;
    contAgregar.hidden = true;

    //resetearTxt();
}
function MostrarModificar(){
    var contAgregar = document.getElementById("contenedorModificar");
    var btn = document.getElementById("btnAgregar");
    contAgregar.hidden=false;
    btn.hidden = true;

   }

function clickAgregar(){
    //mostrarFormulario(true);

     // esto no//resetearTxt();
     var contAgregar = document.getElementById("contenedor");
    var btn = document.getElementById("btnAgregar");
    contAgregar.hidden=false;
    btn.hidden = true;

}
function clickCerrarModificar(){
    //mostrarFormulario(false);
    var contAgregar = document.getElementById("contenedorModificar");
    var btnC= document.getElementById("btnCerrar");
    var btnAgregar = document.getElementById("btnAgregar");
    //document.getElementById("nombre").value = "";
    //document.getElementById("apellido").value = "";
    btnAgregar.hidden = false;
    btnCerrar.hidden = false;
    contAgregar.hidden = true;

    //resetearTxt();
}


//#endregion
//#region comentarios
// function agregarFila(arrayDatosFila){
//     var filaHtml = crearHtmlFila(arrayDatosFila);
//     var tbody = document.getElementById("bodyTabla");

//     tbody.innerHTML += filaHtml;
// }
// function crearGrilla(per) //funcion del profe
// {
// var tCuerpo = document.getElementById("tbody");
// var personas = JSON.parse(per);


//     for(var i=0;i<personas.length;i++)
//     {
//         var row = document.createElement("tr");
//         var obj = personas[i];
//         var colums = Object.keys(obj);

//         for(var j=0;j<colums.length;j++)
//         {
//             var cel = document.createElement("td");
//             var text = document.createTextNode(obj[colums[j]]);
//             cel.appendChild(text);
//             row.appendChild(cel);

//         }
//         var cel = document.createElement("td");
//         var link = document.createElement("a");
//         link.setAttribute("href","#");
//         var text = document.createTextNode("borrar");

//         link.appendChild(text);
//         cel.appendChild(link);
//         row.appendChild(cel);
        
//         tCuerpo.appendChild(row);
//     }


// }


// function crearHtmlFila(arrayDatosFila){
//     var filaHtml = "<tr><td>"+arrayDatosFila["nombre"]+
//     "</td><td>"+arrayDatosFila["apellido"]+
//     "</td><td>"+arrayDatosFila["fecha"]+
//     "</td><td>"+arrayDatosFila["telefono"]+"</td></tr>";
//     return filaHtml;
//}
//#endregion 
