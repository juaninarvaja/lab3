namespace parcial
{

    export class Auto extends vehiculo
    {
        public puertas:number;
        //public legajo:number;

        constructor(id:number,marca:string,modelo:string,precio:number,puertas:number)
        {
            super(id,marca,modelo,precio);
            this.puertas =puertas;
            //this.legajo = legajo;
        }
        // public toJson():string
        // {
        //     return JSON.stringify(this);
        // }
        public CamionetaToJson():string{
            return JSON.stringify(this);
        }

        public CrearElementoTr(index:any):HTMLTableRowElement{
            let tr:HTMLTableRowElement = document.createElement("tr");
                    
            //let tdId = this.CrearElementoTd("", "id");
            let tdId = this.CrearElementoTd(String(this.id), "id");                
            let tdMarca= this.CrearElementoTd(this.marca, "marca");
            let tdModelo = this.CrearElementoTd(this.modelo, "modelo"); 
            let tdPrecio = this.CrearElementoTd(String(this.precio), "precio"); 
           // let tdCuatroxCuatro = this.CrearElementoTd(String(this.puertas), "puertas");     
            let tdAccion = this.CrearElementoTdAccion(index);   
            
           // tr.appendChild(tdId);  
            tr.appendChild(tdId);  
            tr.appendChild(tdMarca);
            tr.appendChild(tdModelo);                                              
            tr.appendChild(tdPrecio);      
           // tr.appendChild(tdCuatroxCuatro);
            tr.appendChild(tdAccion);
                          
            return tr;
        }
    
        private CrearElementoTd(dato:string, key:string):HTMLTableCellElement{
            let td:HTMLTableCellElement = document.createElement("td");
            td.setAttribute("name", key);
            if(key == "id"){
                //td.hidden = true;
            }            

            td.innerHTML = dato;
        
            return td;
        }
        
        private CrearElementoTdAccion(index:any):HTMLTableCellElement{
            let btnBorrar = document.createElement("button");
            let btnModificar = document.createElement("button");
            let td:HTMLTableCellElement = document.createElement("td");                        
            let strBtnMod:string = "accionModificar";//+ index;
            let strBtnBorrar:string = "accionBorrar";//+ index;

            // var icon = document.createElement("span");
            // var iconM = document.createElement("span");
            // iconM.className ="oi oi-pencil";

            //  icon.className ="oi oi-trash";
            //  iconM.setAttribute("name",strBtnMod);
            //  icon.setAttribute("name",strBtnBorrar);
            //  td.appendChild(icon);
            //  td.appendChild(iconM);

            // btnModificar.setAttribute("name",strBtnMod);
             btnBorrar.setAttribute("name",strBtnBorrar);
             btnBorrar.innerHTML="Borrar";
            // btnModificar.innerHTML="Modificar";
            // btnModificar.setAttribute("class","botonM");
             btnBorrar.setAttribute("class","botonB");
            
            // td.appendChild(btnModificar);
             td.appendChild(btnBorrar);

            // var strAccMod = "#accionModificar"+index;
            // $(strAccMod).click(Manejadora.hicieronClick);


            return td;
        }


    }
}