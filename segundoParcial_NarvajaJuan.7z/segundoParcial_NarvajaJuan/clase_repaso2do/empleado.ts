
namespace parcial
{

    export class Empleado extends Persona
    {
        public horario:string;
        public legajo:number;

        constructor(nombre:string,apellido:string,edad:number,horario:string,legajo:number)
        {
            super(nombre,apellido,edad);
            this.horario =horario;
            this.legajo = legajo;
        }
        // public toJson():string
        // {
        //     return JSON.stringify(this);
        // }
        public EmpleadoToJson():string{
            return JSON.stringify(this);
        }

        public CrearElementoTr(index:any):HTMLTableRowElement{
            let tr:HTMLTableRowElement = document.createElement("tr");
                    
            //let tdId = this.CrearElementoTd("", "id");
            let tdEdad = this.CrearElementoTd(String(this.edad), "edad");                
            let tdNombre = this.CrearElementoTd(this.nombre, "nombre");
            let tdApellido = this.CrearElementoTd(this.apellido, "apellido"); 
            let tdHorario = this.CrearElementoTd(this.horario, "horario"); 
            let tdLegajo = this.CrearElementoTd(String(this.legajo), "legajo");     
            let tdAccion = this.CrearElementoTdAccion(index);   
            
           // tr.appendChild(tdId);  
            tr.appendChild(tdNombre);  
            tr.appendChild(tdApellido);
            tr.appendChild(tdEdad);                                              
            tr.appendChild(tdLegajo);      
            tr.appendChild(tdHorario);
            tr.appendChild(tdAccion);
                          
            return tr;
        }
    
        private CrearElementoTd(dato:string, key:string):HTMLTableCellElement{
            let td:HTMLTableCellElement = document.createElement("td");
            td.setAttribute("name", key);
            if(key == "id"){
                //td.hidden = true;
            }            

            td.innerHTML = dato;
        
            return td;
        }
        
        private CrearElementoTdAccion(index:any):HTMLTableCellElement{
            let btnBorrar = document.createElement("button");
            let btnModificar = document.createElement("button");
            let td:HTMLTableCellElement = document.createElement("td");                        
            let strBtnMod:string = "accionModificar";//+ index;
            let strBtnBorrar:string = "accionBorrar";//+ index;

            var icon = document.createElement("span");
            var iconM = document.createElement("span");
            iconM.className ="oi oi-pencil";

             icon.className ="oi oi-trash";
             iconM.setAttribute("name",strBtnMod);
             icon.setAttribute("name",strBtnBorrar);
             td.appendChild(icon);
             td.appendChild(iconM);

            // btnModificar.setAttribute("name",strBtnMod);
            // btnBorrar.setAttribute("name",strBtnBorrar);
            // btnBorrar.innerHTML="Borrar";
            // btnModificar.innerHTML="Modificar";
            // btnModificar.setAttribute("class","botonM");
            // btnBorrar.setAttribute("class","botonB");
            
            // td.appendChild(btnModificar);
            // td.appendChild(btnBorrar);

            // var strAccMod = "#accionModificar"+index;
            // $(strAccMod).click(Manejadora.hicieronClick);


            return td;
        }


    }

}