
namespace parcial
{
    $(document).ready(function() {
        // $("#btnCancelar").click(Manejadora.limpiarFormulario);
        // $("#btnGuardar").click(Manejadora.agregarEmpleado);
        // $("#mostrar").click(Manejadora.mostrarEmpleados);
        // $("#promedio").click(Manejadora.pruebaPromedio);
        // $("#btnModificar").click(function(event)
        // {
        //     Manejadora.modificarEnGrilla();
        //  });
        //  $("#filtrarPromedio").click(Manejadora.filtrarPromedio);
        $("#sacarProm").click(Manejadora.sacarPromedio);
        $("#alta").click(Manejadora.mostrarFormulario);
        $("#limpiar").click(Manejadora.limpiarLS);
        $("#mostrar").click(Manejadora.mostrarVehiculos);
        $("#altaVehiculo").click(Manejadora.cargarVehiculo);
        $("#tipoV").change(Manejadora.validaTipoVehiculo);
        $("#TipoS").change(Manejadora.mostrarVehiculosSelecc);
    });
    var arrayJSon:any = new Array();
    //var arrayAutos:any = new Array();
    //var arrayCamionetas:any = new Array();
   // var arrayEmpleados: Empleado[] = new Array();
    var guardado = localStorage.getItem("key");
    //console.log("se ejecuto el arrayEmpleados");
    if(guardado != null)
    {

     arrayJSon = JSON.parse(guardado);

    }
    var trModificar:any;
    
    export class Manejadora
    {
        public static mostrarFormulario():void
        {
           console.log("entra");
            //$("#formAlta").attr("hidden",false);
            $("#formAlta").modal('show');
        }
        public static cargarVehiculo():void
        {
           console.log("entra");
           let id:number= Number($("#id").val());
             let marca:string = String($("#marca").val());
             let modelo:string = String($("#modelo").val());
            let precio:number= Number($("#precio").val());
            let tipoV = $("#tipoV").val();
           
            //console.log(tipoV);
           // let turno:string = String($("#turno").val());
            let idA = Manejadora.obtenerultimoId() + 1;
            $("#id").val("esto");
            console.log(idA);
            if(marca != "" && modelo != "" && precio != 0)
            {
                if(tipoV == "Camioneta")
                {
                    let es4x4:boolean =$("#ch4x4").is(":checked");
                    
                    let unCamio:Camioneta = new Camioneta(idA,marca,modelo,precio,es4x4);
                    
                  
                    arrayJSon.push(unCamio);
                    console.log(arrayJSon);


                }
                else if(tipoV == "Auto")
                {
                    let puertas:number =Number($("#puertas").val());
                    
                    let unAuto:Auto = new Auto(idA,marca,modelo,precio,puertas);
                    
                  
                    arrayJSon.push(unAuto);
                    console.log(arrayJSon);
                }


    

            localStorage.removeItem("key");
            localStorage.setItem("key",JSON.stringify(arrayJSon));
                       }
                       // let legajo 
                   
            //$("#formAlta").attr("hidden",false);
            
            Manejadora.limpiarFormulario();
            
        }

        public static limpiarFormulario():void
        {
            $("#id").val("");
            $("#marca").val("");
            $("#modelo").val("");
            $("#precio").val("");
            $("#puertas").val(""); 
        }
        public static obtenerultimoId():any
        {
            if(arrayJSon.length != 0)
            {
                // let i = arrayJSon.reduce(function(valorAnterior:any, valorActual:any, indice:any, vector:any){
                    
                //  return Number(indice);
                //      });
             return arrayJSon.length;
            }
            else{ return -1}
              //console.log(i);
        }
        public static  validaTipoVehiculo():void
        {

          
            //console.log("te meustro las cosas de la camioneta");
            let bool:boolean = false;
            let val = $("#tipoV").val();
            if(val == "Camioneta")
            {
                $("#es4x4").attr("hidden",bool);
                $("#puertas").attr("hidden",!(bool));
               // console.log("te meustro las cosas de la camioneta");
            }
            else if(val == "Auto")
            {
                $("#puertas").attr("hidden",bool);
                $("#es4x4").attr("hidden",!(bool));
            }
        }
        public static mostrarVehiculos():void
        {
            console.log(arrayJSon.length);
            $("#bodyTabla").html("");
            //for(let i=0; i<arrayEmpleados.length; i++)
            for(let i=0; i<arrayJSon.length; i++)
            {
                // let data = JSON.parse(String(arrayEmpleados.indexOf()));              
                let data = arrayJSon[i];            
                Manejadora.datosToGrilla(data, i);
            }   
           // arrayEmpleados;
        //    $("[name='accionModificar']").click(function(event)
        //    {
        //     let id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
        //        Manejadora.modificar(id);
        //     });  
            $("[name='accionBorrar']").click(function(event)
            {
             let id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
             console.log(id);
             Manejadora.eliminar(id);
             });   
     }

     public static mostrarVehiculosSelecc():void
     {

    
        
         //console.log(arrayJSon.length);
         $("#bodyTabla").html("");
         //arrayCamionetas.lenght = 0;
         let val = $("#TipoS").val();
         //for(let i=0; i<arrayEmpleados.length; i++)
         for(let i=0; i<arrayJSon.length; i++)
         {
             if(arrayJSon[i].cuatroXcuatro != null && val == "Camioneta" )
             {

                let data = arrayJSon[i];            
                Manejadora.datosToGrilla(data, i);
                //arrayCamionetas.push(arrayJSon[i]);
             }
             else if (arrayJSon[i].puertas != null && val == "Auto" )
             {
                let data = arrayJSon[i];            
                Manejadora.datosToGrilla(data, i);
                //arrayAutos.push(arrayJSon[i]);
             }
             // let data = JSON.parse(String(arrayEmpleados.indexOf()));              
          
         }   
         $("[name='accionBorrar']").click(function(event)
         {
          let id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
          console.log(id);
          Manejadora.eliminar(id);
          });   

        }

        public static  sacarPromedio():void
        {
            let acumulador:number = 0;
            let largo = arrayJSon.lenght;
            for(let i = 0; i < largo;i++)
            {
                console.log("entra");
                
                acumulador += Number(arrayJSon[i].precio);               
            }
            console.log(acumulador);

            let promedio = acumulador / arrayJSon.lenght;
            $("#promedioC").val(promedio);

        }

    //  public static CalcularPromedios()
    //  {
    //     let val = $("#TipoS").val();
    //     if(val == "Camioneta")
    //     {
    //         console.log(arrayCamionetas);
    //     }



    //  }

     public static limpiarLS():void
     {
        localStorage.clear();
     } 


//         public static  agregarEmpleado():void
//         {
            
//             let nombre:string = String($("#nombre").val());
//             let apellido:string = String($("#apellido").val());
//             let edad:number = Number($("#edad").val());
//             let legajo:number= Number($("#legajo").val());
//             let turno:string = String($("#turno").val());

//             if(nombre != "" && apellido != "" && edad != 0 && legajo != 0  && turno != "")
//             {
//                 let unEmpleado:Empleado = new Empleado(nombre,apellido,edad,turno,legajo);
//                 //console.log(unEmpleado);
//                 arrayEmpleados.push(unEmpleado);
//                 localStorage.removeItem("key");
//                 localStorage.setItem("key",JSON.stringify(arrayEmpleados));
//             }
//             // let legajo 
        
//         }

//         public static filtrarPromedio():void
//         {
//             //console.log("entra a filtrar");
//             let $turno = $("#turnoPromedio").val();
//             let arrayEmpleadosFiltrados: Empleado[] = new Array();
//             //console.log("puso turno" +$turno);
           
//             //console.log(arrayEmpleados);
//             let auxEmpleados: Empleado[] = new Array();
//             arrayEmpleadosFiltrados = arrayEmpleados.reduce(function(valorAnterior,valorActual, indice, vector){
//                 let promedio:number = 0;
//                 let contador:number = 0;
               
//                if(indice === 1)
//                {
//                 if(vector[0].horario == "Mañana"  && $turno == "Mañana")
//                 {
//                     //console.log(vector[0]);
//                     auxEmpleados.push(vector[0]);
//                     // promedio += vector[0].edad;
//                     // contador++;
//                 }
//                 else if(vector[0].horario == "Tarde"  && $turno == "Tarde")
//                 {
//                     //console.log(vector[0])
//                     auxEmpleados.push(vector[0]);
//                     // promedio+= vector[0].edad;
//                     // contador++;
//                    // console.log("el primero es de tarde");
//                 }
//                 //console.log(valorAnterior);
//                }
//             //sconsole.log(indice);  
//            // console.log(vector);  
//            if(valorActual.horario == "Mañana" && $turno == "Mañana")
//            {
//             auxEmpleados.push(valorActual);
//             // promedio += vector[0].edad;
//             // contador++;
//             //console.log("puso turno mañana");
//             //console.log(valorActual);
//            }
//            else if(valorActual.horario == "Tarde" && $turno == "Tarde")
//            {
//             auxEmpleados.push(valorActual);
//             // promedio += vector[0].edad;
//             // contador++;
//             //console.log(valorActual);
//             //console.log("puso turno noche");
//            }
//               // 
//              return auxEmpleados; //valorAnterior + valorActual;
//           });

//           console.log(arrayEmpleadosFiltrados);
//           let contador:number = 0;
//           for(let k=0; k<arrayEmpleadosFiltrados.length;k++)
//           {
//              contador += Number(arrayEmpleadosFiltrados[k].edad);
//             }
//             console.log("sumatoria de edades" + contador);
//             $("#pValorPromedio").append(String(contador));
//             $("#myModalResProm").modal('show');


//         }



//         //#region MOSTRAR
//         public static mostrarEmpleados():void
//         {
//             //console.log(arrayEmpleados.length);
//             $("#bodyTabla").html("");
//             //for(let i=0; i<arrayEmpleados.length; i++)
//             for(let i=0; i<arrayEmpleados.length; i++)
//             {
//                 // let data = JSON.parse(String(arrayEmpleados.indexOf()));              
//                 let data = arrayEmpleados[i];            
//                 Manejadora.datosToGrilla(data, i);
//             }   
//            // arrayEmpleados;
//            $("[name='accionModificar']").click(function(event)
//            {
//             let id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
//                Manejadora.modificar(id);
//             });  
//             $("[name='accionBorrar']").click(function(event)
//             {
//              let id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
//                 Manejadora.eliminar(id);
//              });   
//             }
//             //#endregion
//          //#region modificar   
//         public static modificar(i:number):void
//         {
//             Manejadora.OcultarBtnMod(false);
//             Manejadora.OcultarBtnGuardar(true);
//             var hijos = $("#"+i);
//             if(hijos != null)
//             {
//                 console.log("el id del tr es" + hijos[0].id);

//                 for(let j=0;j< hijos[0].parentNode.children.length;j++)
//                 {
//                     if(i == Number(hijos[0].parentNode.children[j].id))
//                     {
//                         trModificar = hijos[0].parentNode.children[j];
//                         //console.log(trModificar);
//                        let trJson = Manejadora.trToJson(hijos[0].parentNode.children[j]);
//                        if(trJson!=null)
//                        {
//                         $("#nombre").val(trJson.nombre);
//                         $("#apellido").val(trJson.apellido);
//                         $("#edad").val(trJson.edad);
//                         $("#legajo").val(trJson.legajo);
//                         $("#turno").val(trJson.horario);
                       
                        
//                        }
//                     }        
//                 }
//             }
//             }
           
//         public static modificarEnGrilla()
//         {
//             trModificar.cells.nombre.innerText = $("#nombre").val();
//             trModificar.cells.apellido.innerText = $("#apellido").val();
//             trModificar.cells.edad.innerText = $("#edad").val();
//             trModificar.cells.legajo.innerText = $("#legajo").val();
//             trModificar.cells.horario.innerText = $("#turno").val();
//             let objJson = Manejadora.trToJson(trModificar);
//             Manejadora.limpiarFormulario();
//             console.log("hicist click y lo tomo");
//             var jsonTr = Manejadora.trToJson(trModificar);
//             if(jsonTr!=null)
//             {
//                 let objEmpleado: Empleado = new Empleado(
//                     jsonTr.nombre, jsonTr.apellido, jsonTr.edad, jsonTr.horario, jsonTr.legajo
//                 );

//                 arrayEmpleados[trModificar.id] = objEmpleado;
//                 localStorage.removeItem("key");
//                 localStorage.setItem("key",JSON.stringify(arrayEmpleados));

//             }

          
            
//         }
//          //#endregion
//         //#region  eliminar
        public static eliminar(i:number):void
        {
            var hijos = $("#"+i);
            console.log(arrayJSon[i]);
            if(arrayJSon[i] != undefined)
            {
                if(hijos != null)
                {
                    console.log("el id del tr es" + hijos[0].id);
    
                    for(let j=0;j< hijos[0].parentNode.children.length;j++)
                    {
                        if(i == Number(hijos[0].parentNode.children[j].id))
                        {
    
                       arrayJSon.splice(i,1);
                       localStorage.removeItem("key");
                       localStorage.setItem("key",JSON.stringify(arrayJSon)); 
    
                        }
                        
                    }
                    Manejadora.mostrarVehiculos();
                }
            }

            
            //#endregion
        }

        public filtrarPorHorario():void
        {

        }
        public promedioEdadPorHorario():void
        {

        }
        private static datosToGrilla(data: any, index:any): void{
            

            if(arrayJSon[index].es4x4 != null)
            {
                let objCamio:Camioneta = new Camioneta(data.id,data.marca,data.modelo,data.precio,data.cuatroXcuatro);
                let tr = objCamio.CrearElementoTr(index);
                tr.setAttribute("id",index);  
                $("#bodyTabla").append(tr);
            }
            else
            {
                let objAuto:Auto = new Auto(data.id,data.marca,data.modelo,data.precio,data.puertas);
                let tr = objAuto.CrearElementoTr(index);
                tr.setAttribute("id",index);  
                $("#bodyTabla").append(tr);
            }


           // console.log("empleado en la grilla sera" + objEmpleado.personaToJson());
            
         
        }

//         private static GetTr():void{
//             let tr = $(this).parent().parent();
//             console.log("dos");
//             //Manejadora.Eliminar()  

//         }

//         public static trToJson(tr:any)
//         {
//             if(tr!=null)
//             {
                
//                 console.log(tr);

//                 var ObjJson ={
//                     "nombre":tr.cells.nombre.innerText,
//                     "apellido":tr.cells.apellido.innerText,
//                     "edad":tr.cells.edad.innerText,
//                     "horario":tr.cells.horario.innerText,
//                     "legajo":tr.cells.legajo.innerText

//                 }
//                 return ObjJson;

//             }
//             return null;
//         }
//         public static pruebaPromedio()
//         {
//             $("#myModal").modal('show');

//         }

// //#region hiddens
//         public static OcultarBtnMod(valor:any)
//         {
//              $("#btnModificar").attr("hidden",valor);
//         }   

//         public static OcultarBtnGuardar(valor:any)
//         {
//              $("#btnGuardar").attr("hidden",valor);
//         }   
// //#endregion

     }
}