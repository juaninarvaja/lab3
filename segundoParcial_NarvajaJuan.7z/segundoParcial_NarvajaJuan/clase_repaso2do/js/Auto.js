"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var parcial;
(function (parcial) {
    var Auto = /** @class */ (function (_super) {
        __extends(Auto, _super);
        //public legajo:number;
        function Auto(id, marca, modelo, precio, puertas) {
            var _this = _super.call(this, id, marca, modelo, precio) || this;
            _this.puertas = puertas;
            return _this;
            //this.legajo = legajo;
        }
        // public toJson():string
        // {
        //     return JSON.stringify(this);
        // }
        Auto.prototype.CamionetaToJson = function () {
            return JSON.stringify(this);
        };
        Auto.prototype.CrearElementoTr = function (index) {
            var tr = document.createElement("tr");
            //let tdId = this.CrearElementoTd("", "id");
            var tdId = this.CrearElementoTd(String(this.id), "id");
            var tdMarca = this.CrearElementoTd(this.marca, "marca");
            var tdModelo = this.CrearElementoTd(this.modelo, "modelo");
            var tdPrecio = this.CrearElementoTd(String(this.precio), "precio");
            // let tdCuatroxCuatro = this.CrearElementoTd(String(this.puertas), "puertas");     
            var tdAccion = this.CrearElementoTdAccion(index);
            // tr.appendChild(tdId);  
            tr.appendChild(tdId);
            tr.appendChild(tdMarca);
            tr.appendChild(tdModelo);
            tr.appendChild(tdPrecio);
            // tr.appendChild(tdCuatroxCuatro);
            tr.appendChild(tdAccion);
            return tr;
        };
        Auto.prototype.CrearElementoTd = function (dato, key) {
            var td = document.createElement("td");
            td.setAttribute("name", key);
            if (key == "id") {
                //td.hidden = true;
            }
            td.innerHTML = dato;
            return td;
        };
        Auto.prototype.CrearElementoTdAccion = function (index) {
            var btnBorrar = document.createElement("button");
            var btnModificar = document.createElement("button");
            var td = document.createElement("td");
            var strBtnMod = "accionModificar"; //+ index;
            var strBtnBorrar = "accionBorrar"; //+ index;
            // var icon = document.createElement("span");
            // var iconM = document.createElement("span");
            // iconM.className ="oi oi-pencil";
            //  icon.className ="oi oi-trash";
            //  iconM.setAttribute("name",strBtnMod);
            //  icon.setAttribute("name",strBtnBorrar);
            //  td.appendChild(icon);
            //  td.appendChild(iconM);
            // btnModificar.setAttribute("name",strBtnMod);
            btnBorrar.setAttribute("name", strBtnBorrar);
            btnBorrar.innerHTML = "Borrar";
            // btnModificar.innerHTML="Modificar";
            // btnModificar.setAttribute("class","botonM");
            btnBorrar.setAttribute("class", "botonB");
            // td.appendChild(btnModificar);
            td.appendChild(btnBorrar);
            // var strAccMod = "#accionModificar"+index;
            // $(strAccMod).click(Manejadora.hicieronClick);
            return td;
        };
        return Auto;
    }(parcial.vehiculo));
    parcial.Auto = Auto;
})(parcial || (parcial = {}));
