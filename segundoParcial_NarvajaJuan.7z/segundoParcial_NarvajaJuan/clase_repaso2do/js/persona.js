"use strict";
var parcial;
(function (parcial) {
    var Persona = /** @class */ (function () {
        function Persona(nombre, apellido, edad) {
            this.nombre = nombre;
            this.apellido = apellido;
            this.edad = edad;
        }
        Persona.prototype.personaToJson = function () {
            return JSON.stringify(this);
        };
        Object.defineProperty(Persona.prototype, "Edad", {
            get: function () {
                return this.edad;
            },
            enumerable: true,
            configurable: true
        });
        return Persona;
    }());
    parcial.Persona = Persona;
})(parcial || (parcial = {}));
