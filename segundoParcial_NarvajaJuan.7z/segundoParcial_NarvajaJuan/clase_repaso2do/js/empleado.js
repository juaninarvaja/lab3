"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var parcial;
(function (parcial) {
    var Empleado = /** @class */ (function (_super) {
        __extends(Empleado, _super);
        function Empleado(nombre, apellido, edad, horario, legajo) {
            var _this = _super.call(this, nombre, apellido, edad) || this;
            _this.horario = horario;
            _this.legajo = legajo;
            return _this;
        }
        // public toJson():string
        // {
        //     return JSON.stringify(this);
        // }
        Empleado.prototype.EmpleadoToJson = function () {
            return JSON.stringify(this);
        };
        Empleado.prototype.CrearElementoTr = function (index) {
            var tr = document.createElement("tr");
            //let tdId = this.CrearElementoTd("", "id");
            var tdEdad = this.CrearElementoTd(String(this.edad), "edad");
            var tdNombre = this.CrearElementoTd(this.nombre, "nombre");
            var tdApellido = this.CrearElementoTd(this.apellido, "apellido");
            var tdHorario = this.CrearElementoTd(this.horario, "horario");
            var tdLegajo = this.CrearElementoTd(String(this.legajo), "legajo");
            var tdAccion = this.CrearElementoTdAccion(index);
            // tr.appendChild(tdId);  
            tr.appendChild(tdNombre);
            tr.appendChild(tdApellido);
            tr.appendChild(tdEdad);
            tr.appendChild(tdLegajo);
            tr.appendChild(tdHorario);
            tr.appendChild(tdAccion);
            return tr;
        };
        Empleado.prototype.CrearElementoTd = function (dato, key) {
            var td = document.createElement("td");
            td.setAttribute("name", key);
            if (key == "id") {
                //td.hidden = true;
            }
            td.innerHTML = dato;
            return td;
        };
        Empleado.prototype.CrearElementoTdAccion = function (index) {
            var btnBorrar = document.createElement("button");
            var btnModificar = document.createElement("button");
            var td = document.createElement("td");
            var strBtnMod = "accionModificar"; //+ index;
            var strBtnBorrar = "accionBorrar"; //+ index;
            var icon = document.createElement("span");
            var iconM = document.createElement("span");
            iconM.className = "oi oi-pencil";
            icon.className = "oi oi-trash";
            iconM.setAttribute("name", strBtnMod);
            icon.setAttribute("name", strBtnBorrar);
            td.appendChild(icon);
            td.appendChild(iconM);
            // btnModificar.setAttribute("name",strBtnMod);
            // btnBorrar.setAttribute("name",strBtnBorrar);
            // btnBorrar.innerHTML="Borrar";
            // btnModificar.innerHTML="Modificar";
            // btnModificar.setAttribute("class","botonM");
            // btnBorrar.setAttribute("class","botonB");
            // td.appendChild(btnModificar);
            // td.appendChild(btnBorrar);
            // var strAccMod = "#accionModificar"+index;
            // $(strAccMod).click(Manejadora.hicieronClick);
            return td;
        };
        return Empleado;
    }(parcial.Persona));
    parcial.Empleado = Empleado;
})(parcial || (parcial = {}));
