"use strict";
var parcial;
(function (parcial) {
    $(document).ready(function () {
        // $("#btnCancelar").click(Manejadora.limpiarFormulario);
        // $("#btnGuardar").click(Manejadora.agregarEmpleado);
        // $("#mostrar").click(Manejadora.mostrarEmpleados);
        // $("#promedio").click(Manejadora.pruebaPromedio);
        // $("#btnModificar").click(function(event)
        // {
        //     Manejadora.modificarEnGrilla();
        //  });
        //  $("#filtrarPromedio").click(Manejadora.filtrarPromedio);
        $("#sacarProm").click(Manejadora.sacarPromedio);
        $("#alta").click(Manejadora.mostrarFormulario);
        $("#limpiar").click(Manejadora.limpiarLS);
        $("#mostrar").click(Manejadora.mostrarVehiculos);
        $("#altaVehiculo").click(Manejadora.cargarVehiculo);
        $("#tipoV").change(Manejadora.validaTipoVehiculo);
        $("#TipoS").change(Manejadora.mostrarVehiculosSelecc);
    });
    var arrayJSon = new Array();
    //var arrayAutos:any = new Array();
    //var arrayCamionetas:any = new Array();
    // var arrayEmpleados: Empleado[] = new Array();
    var guardado = localStorage.getItem("key");
    //console.log("se ejecuto el arrayEmpleados");
    if (guardado != null) {
        arrayJSon = JSON.parse(guardado);
    }
    var trModificar;
    var Manejadora = /** @class */ (function () {
        function Manejadora() {
        }
        Manejadora.mostrarFormulario = function () {
            console.log("entra");
            //$("#formAlta").attr("hidden",false);
            $("#formAlta").modal('show');
        };
        Manejadora.cargarVehiculo = function () {
            console.log("entra");
            var id = Number($("#id").val());
            var marca = String($("#marca").val());
            var modelo = String($("#modelo").val());
            var precio = Number($("#precio").val());
            var tipoV = $("#tipoV").val();
            //console.log(tipoV);
            // let turno:string = String($("#turno").val());
            var idA = Manejadora.obtenerultimoId() + 1;
            $("#id").val("esto");
            console.log(idA);
            if (marca != "" && modelo != "" && precio != 0) {
                if (tipoV == "Camioneta") {
                    var es4x4 = $("#ch4x4").is(":checked");
                    var unCamio = new parcial.Camioneta(idA, marca, modelo, precio, es4x4);
                    arrayJSon.push(unCamio);
                    console.log(arrayJSon);
                }
                else if (tipoV == "Auto") {
                    var puertas = Number($("#puertas").val());
                    var unAuto = new parcial.Auto(idA, marca, modelo, precio, puertas);
                    arrayJSon.push(unAuto);
                    console.log(arrayJSon);
                }
                localStorage.removeItem("key");
                localStorage.setItem("key", JSON.stringify(arrayJSon));
            }
            // let legajo 
            //$("#formAlta").attr("hidden",false);
            Manejadora.limpiarFormulario();
        };
        Manejadora.limpiarFormulario = function () {
            $("#id").val("");
            $("#marca").val("");
            $("#modelo").val("");
            $("#precio").val("");
            $("#puertas").val("");
        };
        Manejadora.obtenerultimoId = function () {
            if (arrayJSon.length != 0) {
                // let i = arrayJSon.reduce(function(valorAnterior:any, valorActual:any, indice:any, vector:any){
                //  return Number(indice);
                //      });
                return arrayJSon.length;
            }
            else {
                return -1;
            }
            //console.log(i);
        };
        Manejadora.validaTipoVehiculo = function () {
            //console.log("te meustro las cosas de la camioneta");
            var bool = false;
            var val = $("#tipoV").val();
            if (val == "Camioneta") {
                $("#es4x4").attr("hidden", bool);
                $("#puertas").attr("hidden", !(bool));
                // console.log("te meustro las cosas de la camioneta");
            }
            else if (val == "Auto") {
                $("#puertas").attr("hidden", bool);
                $("#es4x4").attr("hidden", !(bool));
            }
        };
        Manejadora.mostrarVehiculos = function () {
            console.log(arrayJSon.length);
            $("#bodyTabla").html("");
            //for(let i=0; i<arrayEmpleados.length; i++)
            for (var i = 0; i < arrayJSon.length; i++) {
                // let data = JSON.parse(String(arrayEmpleados.indexOf()));              
                var data = arrayJSon[i];
                Manejadora.datosToGrilla(data, i);
            }
            // arrayEmpleados;
            //    $("[name='accionModificar']").click(function(event)
            //    {
            //     let id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
            //        Manejadora.modificar(id);
            //     });  
            $("[name='accionBorrar']").click(function (event) {
                var id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
                console.log(id);
                Manejadora.eliminar(id);
            });
        };
        Manejadora.mostrarVehiculosSelecc = function () {
            //console.log(arrayJSon.length);
            $("#bodyTabla").html("");
            //arrayCamionetas.lenght = 0;
            var val = $("#TipoS").val();
            //for(let i=0; i<arrayEmpleados.length; i++)
            for (var i = 0; i < arrayJSon.length; i++) {
                if (arrayJSon[i].cuatroXcuatro != null && val == "Camioneta") {
                    var data = arrayJSon[i];
                    Manejadora.datosToGrilla(data, i);
                    //arrayCamionetas.push(arrayJSon[i]);
                }
                else if (arrayJSon[i].puertas != null && val == "Auto") {
                    var data = arrayJSon[i];
                    Manejadora.datosToGrilla(data, i);
                    //arrayAutos.push(arrayJSon[i]);
                }
                // let data = JSON.parse(String(arrayEmpleados.indexOf()));              
            }
            $("[name='accionBorrar']").click(function (event) {
                var id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
                console.log(id);
                Manejadora.eliminar(id);
            });
        };
        Manejadora.sacarPromedio = function () {
            var acumulador = 0;
            var largo = arrayJSon.lenght;
            for (var i = 0; i < largo; i++) {
                console.log("entra");
                acumulador += Number(arrayJSon[i].precio);
            }
            console.log(acumulador);
            var promedio = acumulador / arrayJSon.lenght;
            $("#promedioC").val(promedio);
        };
        //  public static CalcularPromedios()
        //  {
        //     let val = $("#TipoS").val();
        //     if(val == "Camioneta")
        //     {
        //         console.log(arrayCamionetas);
        //     }
        //  }
        Manejadora.limpiarLS = function () {
            localStorage.clear();
        };
        //         public static  agregarEmpleado():void
        //         {
        //             let nombre:string = String($("#nombre").val());
        //             let apellido:string = String($("#apellido").val());
        //             let edad:number = Number($("#edad").val());
        //             let legajo:number= Number($("#legajo").val());
        //             let turno:string = String($("#turno").val());
        //             if(nombre != "" && apellido != "" && edad != 0 && legajo != 0  && turno != "")
        //             {
        //                 let unEmpleado:Empleado = new Empleado(nombre,apellido,edad,turno,legajo);
        //                 //console.log(unEmpleado);
        //                 arrayEmpleados.push(unEmpleado);
        //                 localStorage.removeItem("key");
        //                 localStorage.setItem("key",JSON.stringify(arrayEmpleados));
        //             }
        //             // let legajo 
        //         }
        //         public static filtrarPromedio():void
        //         {
        //             //console.log("entra a filtrar");
        //             let $turno = $("#turnoPromedio").val();
        //             let arrayEmpleadosFiltrados: Empleado[] = new Array();
        //             //console.log("puso turno" +$turno);
        //             //console.log(arrayEmpleados);
        //             let auxEmpleados: Empleado[] = new Array();
        //             arrayEmpleadosFiltrados = arrayEmpleados.reduce(function(valorAnterior,valorActual, indice, vector){
        //                 let promedio:number = 0;
        //                 let contador:number = 0;
        //                if(indice === 1)
        //                {
        //                 if(vector[0].horario == "Mañana"  && $turno == "Mañana")
        //                 {
        //                     //console.log(vector[0]);
        //                     auxEmpleados.push(vector[0]);
        //                     // promedio += vector[0].edad;
        //                     // contador++;
        //                 }
        //                 else if(vector[0].horario == "Tarde"  && $turno == "Tarde")
        //                 {
        //                     //console.log(vector[0])
        //                     auxEmpleados.push(vector[0]);
        //                     // promedio+= vector[0].edad;
        //                     // contador++;
        //                    // console.log("el primero es de tarde");
        //                 }
        //                 //console.log(valorAnterior);
        //                }
        //             //sconsole.log(indice);  
        //            // console.log(vector);  
        //            if(valorActual.horario == "Mañana" && $turno == "Mañana")
        //            {
        //             auxEmpleados.push(valorActual);
        //             // promedio += vector[0].edad;
        //             // contador++;
        //             //console.log("puso turno mañana");
        //             //console.log(valorActual);
        //            }
        //            else if(valorActual.horario == "Tarde" && $turno == "Tarde")
        //            {
        //             auxEmpleados.push(valorActual);
        //             // promedio += vector[0].edad;
        //             // contador++;
        //             //console.log(valorActual);
        //             //console.log("puso turno noche");
        //            }
        //               // 
        //              return auxEmpleados; //valorAnterior + valorActual;
        //           });
        //           console.log(arrayEmpleadosFiltrados);
        //           let contador:number = 0;
        //           for(let k=0; k<arrayEmpleadosFiltrados.length;k++)
        //           {
        //              contador += Number(arrayEmpleadosFiltrados[k].edad);
        //             }
        //             console.log("sumatoria de edades" + contador);
        //             $("#pValorPromedio").append(String(contador));
        //             $("#myModalResProm").modal('show');
        //         }
        //         //#region MOSTRAR
        //         public static mostrarEmpleados():void
        //         {
        //             //console.log(arrayEmpleados.length);
        //             $("#bodyTabla").html("");
        //             //for(let i=0; i<arrayEmpleados.length; i++)
        //             for(let i=0; i<arrayEmpleados.length; i++)
        //             {
        //                 // let data = JSON.parse(String(arrayEmpleados.indexOf()));              
        //                 let data = arrayEmpleados[i];            
        //                 Manejadora.datosToGrilla(data, i);
        //             }   
        //            // arrayEmpleados;
        //            $("[name='accionModificar']").click(function(event)
        //            {
        //             let id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
        //                Manejadora.modificar(id);
        //             });  
        //             $("[name='accionBorrar']").click(function(event)
        //             {
        //              let id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
        //                 Manejadora.eliminar(id);
        //              });   
        //             }
        //             //#endregion
        //          //#region modificar   
        //         public static modificar(i:number):void
        //         {
        //             Manejadora.OcultarBtnMod(false);
        //             Manejadora.OcultarBtnGuardar(true);
        //             var hijos = $("#"+i);
        //             if(hijos != null)
        //             {
        //                 console.log("el id del tr es" + hijos[0].id);
        //                 for(let j=0;j< hijos[0].parentNode.children.length;j++)
        //                 {
        //                     if(i == Number(hijos[0].parentNode.children[j].id))
        //                     {
        //                         trModificar = hijos[0].parentNode.children[j];
        //                         //console.log(trModificar);
        //                        let trJson = Manejadora.trToJson(hijos[0].parentNode.children[j]);
        //                        if(trJson!=null)
        //                        {
        //                         $("#nombre").val(trJson.nombre);
        //                         $("#apellido").val(trJson.apellido);
        //                         $("#edad").val(trJson.edad);
        //                         $("#legajo").val(trJson.legajo);
        //                         $("#turno").val(trJson.horario);
        //                        }
        //                     }        
        //                 }
        //             }
        //             }
        //         public static modificarEnGrilla()
        //         {
        //             trModificar.cells.nombre.innerText = $("#nombre").val();
        //             trModificar.cells.apellido.innerText = $("#apellido").val();
        //             trModificar.cells.edad.innerText = $("#edad").val();
        //             trModificar.cells.legajo.innerText = $("#legajo").val();
        //             trModificar.cells.horario.innerText = $("#turno").val();
        //             let objJson = Manejadora.trToJson(trModificar);
        //             Manejadora.limpiarFormulario();
        //             console.log("hicist click y lo tomo");
        //             var jsonTr = Manejadora.trToJson(trModificar);
        //             if(jsonTr!=null)
        //             {
        //                 let objEmpleado: Empleado = new Empleado(
        //                     jsonTr.nombre, jsonTr.apellido, jsonTr.edad, jsonTr.horario, jsonTr.legajo
        //                 );
        //                 arrayEmpleados[trModificar.id] = objEmpleado;
        //                 localStorage.removeItem("key");
        //                 localStorage.setItem("key",JSON.stringify(arrayEmpleados));
        //             }
        //         }
        //          //#endregion
        //         //#region  eliminar
        Manejadora.eliminar = function (i) {
            var hijos = $("#" + i);
            console.log(arrayJSon[i]);
            if (arrayJSon[i] != undefined) {
                if (hijos != null) {
                    console.log("el id del tr es" + hijos[0].id);
                    for (var j = 0; j < hijos[0].parentNode.children.length; j++) {
                        if (i == Number(hijos[0].parentNode.children[j].id)) {
                            arrayJSon.splice(i, 1);
                            localStorage.removeItem("key");
                            localStorage.setItem("key", JSON.stringify(arrayJSon));
                        }
                    }
                    Manejadora.mostrarVehiculos();
                }
            }
            //#endregion
        };
        Manejadora.prototype.filtrarPorHorario = function () {
        };
        Manejadora.prototype.promedioEdadPorHorario = function () {
        };
        Manejadora.datosToGrilla = function (data, index) {
            if (arrayJSon[index].es4x4 != null) {
                var objCamio = new parcial.Camioneta(data.id, data.marca, data.modelo, data.precio, data.cuatroXcuatro);
                var tr = objCamio.CrearElementoTr(index);
                tr.setAttribute("id", index);
                $("#bodyTabla").append(tr);
            }
            else {
                var objAuto = new parcial.Auto(data.id, data.marca, data.modelo, data.precio, data.puertas);
                var tr = objAuto.CrearElementoTr(index);
                tr.setAttribute("id", index);
                $("#bodyTabla").append(tr);
            }
            // console.log("empleado en la grilla sera" + objEmpleado.personaToJson());
        };
        return Manejadora;
    }());
    parcial.Manejadora = Manejadora;
})(parcial || (parcial = {}));
