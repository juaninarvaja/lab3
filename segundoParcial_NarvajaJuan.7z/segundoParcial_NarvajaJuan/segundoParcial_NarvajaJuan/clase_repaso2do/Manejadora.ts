
namespace parcial
{
    $(document).ready(function() {
        // $("#btnCancelar").click(Manejadora.limpiarFormulario);
        // $("#btnGuardar").click(Manejadora.agregarEmpleado);
        // $("#mostrar").click(Manejadora.mostrarEmpleados);
        // $("#promedio").click(Manejadora.pruebaPromedio);
        // $("#btnModificar").click(function(event)
        // {
        //     Manejadora.modificarEnGrilla();
        //  });
        //  $("#filtrarPromedio").click(Manejadora.filtrarPromedio);
         $("#btnModificar").click(function(event)
        {
            Manejadora.modificarEnGrilla();
         });
        $("#sacarProm").click(Manejadora.sacarPromedio);
        $("#alta").click(Manejadora.mostrarFormulario);
        $("#limpiar").click(Manejadora.limpiarLS);
        $("#mostrar").click(Manejadora.mostrarVehiculos);
        $("#altaVehiculo").click(Manejadora.cargarVehiculo);
        $("#tipoV").change(Manejadora.validaTipoVehiculo);
        $("#TipoS").change(Manejadora.mostrarVehiculosSelecc);
        $("#checkId").change(Manejadora.CamposMostrados);
        $("#checkMarca").change(Manejadora.CamposMostrados);
        $("#checkModelo").change(Manejadora.CamposMostrados);
        $("#checkPrecio").change(Manejadora.CamposMostrados);
    });
    var arrayJSon:any = new Array();
    //var arrayAutos:any = new Array();
    //var arrayCamionetas:any = new Array();
   // var arrayEmpleados: Empleado[] = new Array();
    var guardado = localStorage.getItem("key");
    //console.log("se ejecuto el arrayEmpleados");
    if(guardado != null)
    {

     arrayJSon = JSON.parse(guardado);

    }
    var trModificar:any;
    
    export class Manejadora
    {
        public static mostrarFormulario():void
        {
            //$("#formAlta").attr("hidden",false);
            Manejadora.OcultarBtnMod(true);
            Manejadora.OcultarBtnGuardar(false);
            $("#tipoV").attr("hidden",false);
            $("#ptipoV").attr("hidden",false);

            $("#formAlta").modal('show');

        }
        public static cargarVehiculo():void
        {
           //console.log("entra");
           let id:number= Number($("#id").val());
             let marca:string = String($("#marca").val());
             let modelo:string = String($("#modelo").val());
            let precio:number= Number($("#precio").val());
            let tipoV = $("#tipoV").val();
           
            //console.log(tipoV);
           // let turno:string = String($("#turno").val());
            let idA = Manejadora.obtenerultimoId() + 1;
            //$("#id").val("esto");
            console.log(idA);
            if(marca != "" && modelo != "" && precio != 0)
            {
                if(tipoV == "Camioneta")
                {
                    let es4x4:boolean =$("#ch4x4").is(":checked");
                    
                    let unCamio:Camioneta = new Camioneta(idA,marca,modelo,precio,es4x4);
                    
                  
                    arrayJSon.push(unCamio);
                    console.log(arrayJSon);


                }
                else if(tipoV == "Auto")
                {
                    let puertas:number =Number($("#puertas").val());
                    
                    let unAuto:Auto = new Auto(idA,marca,modelo,precio,puertas);
                    
                  
                    arrayJSon.push(unAuto);
                    console.log(arrayJSon);
                }


    

            localStorage.removeItem("key");
            localStorage.setItem("key",JSON.stringify(arrayJSon));
                       }
                       // let legajo 
                   
            //$("#formAlta").attr("hidden",false);
            
            Manejadora.limpiarFormulario();
            
        }

        public static limpiarFormulario():void
        {
            $("#id").val("");
            $("#marca").val("");
            $("#modelo").val("");
            $("#precio").val("");
            $("#puertas").val(""); 

        }
        public static obtenerultimoId():any
        {
            if(arrayJSon.length != 0)
            {
                 let i:Array<JSON> = arrayJSon.reduce(
                     function(valorAnterior:any, valorActual:any, indice:any, vector:any){
                        
                    return valorActual;
                    
                    });
                  return i.id;
                //      });
            //  return arrayJSon.length;
            }
            else{ return 0}
              //console.log(i);
                    
        }
        public static  validaTipoVehiculo():void
        {

          
            //console.log("te meustro las cosas de la camioneta");
            let bool:boolean = false;
            let val = $("#tipoV").val();
            if(val == "Camioneta")
            {
                $("#es4x4").attr("hidden",bool);
                $("#puertas").attr("hidden",!(bool));
               // console.log("te meustro las cosas de la camioneta");
            }
            else if(val == "Auto")
            {
                $("#puertas").attr("hidden",bool);
                $("#es4x4").attr("hidden",!(bool));
            }
        }
        public static mostrarVehiculos():void
        {
            console.log(arrayJSon.length);
            $("#bodyTabla").html("");
            //for(let i=0; i<arrayEmpleados.length; i++)
            for(let i=0; i<arrayJSon.length; i++)
            {
                // let data = JSON.parse(String(arrayEmpleados.indexOf()));              
                let data = arrayJSon[i];            
                Manejadora.datosToGrilla(data, i);
            }   
           // arrayEmpleados;
           $("[name='accionModificar']").click(function(event)
           {
            let id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
              Manejadora.modificar(id);
            });  
            $("[name='accionBorrar']").click(function(event)
            {
             let id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
             //console.log(id);
             Manejadora.eliminar(id);
             });   
     }

    //  public static mostrarVehiculosSelecc():void
    //  {

    
        
    //      //console.log(arrayJSon.length);
    //      $("#bodyTabla").html("");
    //      //arrayCamionetas.lenght = 0;
    //      let val = $("#TipoS").val();
    //      //for(let i=0; i<arrayEmpleados.length; i++)
    //      for(let i=0; i<arrayJSon.length; i++)
    //      {
    //          if(arrayJSon[i].cuatroXcuatro != null && val == "Camioneta" )
    //          {

    //             let data = arrayJSon[i];            
    //             Manejadora.datosToGrilla(data, i);
    //             //arrayCamionetas.push(arrayJSon[i]);
    //          }
    //          else if (arrayJSon[i].puertas != null && val == "Auto" )
    //          {
    //             let data = arrayJSon[i];            
    //             Manejadora.datosToGrilla(data, i);
    //             //arrayAutos.push(arrayJSon[i]);
    //          }
    //          // let data = JSON.parse(String(arrayEmpleados.indexOf()));              
          
    //      }   
    //      $("[name='accionBorrar']").click(function(event)
    //      {
    //       let id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
    //       console.log(id);
    //       Manejadora.eliminar(id);
    //       });   

    //     }


    public static mostrarVehiculosSelecc():void
    {

        //console.log(arrayJSon.length);
        $("#bodyTabla").html("");
        //arrayCamionetas.lenght = 0;
        let val = $("#TipoS").val();
        let arrayCamios:Array<JSON> = arrayJSon.filter(
            function(obj:JSON)
        {
          return obj.cuatroXcuatro!=undefined;
           
           
        });
        let arrayAutos:Array<JSON> = arrayJSon.filter(
            function(obj:JSON)
        {
          return obj.puertas!=undefined;
           
           
        });
        //console.log(arrayAutos);
        let arrayGeneral:Array<JSON>; 
        if(val=="Camioneta")
        {
            arrayGeneral=arrayCamios;
        }
        else
        {
            arrayGeneral=arrayAutos;
        }

        for(let i=0; i<arrayGeneral.length; i++)
        {
               let data = arrayGeneral[i];            
               Manejadora.datosToGrilla(data, i);
               //arrayCamionetas.push(arrayJSon[i]);
            }

            // let data = JSON.parse(String(arrayEmpleados.indexOf()));                 
        $("[name='accionBorrar']").click(function(event)
        {
         let id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
         console.log(id);
         Manejadora.eliminar(id);
         });   
         $("[name='accionModificar']").click(function(event)
         {
          let id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
            Manejadora.modificar(id);
          });  

       }



        public static  sacarPromedio():void
        {

                let sumatoria:number = arrayJSon.reduce(
                    function(suma:number, item:any){        
                      return suma+=item.precio;
                    }, 0);
                    console.log(sumatoria);
                    if(sumatoria != 0)
                    {
                        sumatoria = sumatoria/arrayJSon.length;     
                    }
                    
                console.log(sumatoria);
                $("#promedioC").val(sumatoria);        

        }


     public static limpiarLS():void
     {
        localStorage.clear();
     } 



//         //#region  eliminar
        public static eliminar(i:number):void
        {
            var hijos = $("#"+i);
            console.log(arrayJSon[i]);
            if(arrayJSon[i] != undefined)
            {
                if(hijos != null)
                {
                    console.log("el id del tr es" + hijos[0].id);
    
                    for(let j=0;j< hijos[0].parentNode.children.length;j++)
                    {
                        if(i == Number(hijos[0].parentNode.children[j].id))
                        {
    
                       arrayJSon.splice(i,1);
                       localStorage.removeItem("key");
                       localStorage.setItem("key",JSON.stringify(arrayJSon)); 
    
                        }
                        
                    }
                    Manejadora.mostrarVehiculos();
                }
            }

            
            //#endregion
        }

     //#region modificar   
        public static modificar(i:number):void
        {
            Manejadora.mostrarFormulario();
            Manejadora.OcultarBtnMod(false);
            Manejadora.OcultarBtnGuardar(true);
            
            $("#tipoV").attr("hidden","true");
            $("#ptipoV").attr("hidden","true");
            var hijos = $("#"+i);
            if(hijos != null)
            {
                console.log("el id del tr es" + hijos[0].id);

                for(let j=0;j< hijos[0].parentNode.children.length;j++)
                {
                    if(i == Number(hijos[0].parentNode.children[j].id))
                    {
                        trModificar = hijos[0].parentNode.children[j];
                        //console.log(trModificar);
                       let trJson = Manejadora.trToJson(hijos[0].parentNode.children[j]);
                       if(trJson!=null)
                       {
                        $("#marca").val(trJson.marca);
                        $("#modelo").val(trJson.modelo);
                        $("#precio").val(trJson.precio);
                        // $("#legajo").val(trJson.legajo);
                        // $("#turno").val(trJson.horario);
                       
                        
                       }
                    }        
                }
            }
            }
        public static trToJson(tr:any)
        {
            if(tr!=null)
            {               
                var ObjJson ={
                    "id": tr.cells.id.innerText,
                    "marca":tr.cells.marca.innerText,
                    "modelo":tr.cells.modelo.innerText,
                    "precio":tr.cells.precio.innerText
                }
                return ObjJson;

            }
            return null;
        }
           
        public static modificarEnGrilla()
        {
            console.log(trModificar);
            trModificar.cells.marca.innerText = $("#marca").val();
            trModificar.cells.modelo.innerText = $("#modelo").val();
            trModificar.cells.precio.innerText = $("#precio").val();
            // trModificar.cells.legajo.innerText = $("#legajo").val();
            // trModificar.cells.horario.innerText = $("#turno").val();
            let objJson = Manejadora.trToJson(trModificar);
            Manejadora.limpiarFormulario();
            console.log("hicist click y lo tomo");
            var jsonTr = Manejadora.trToJson(trModificar);
            if(jsonTr!=null)
            {
                let objNuevo:Camioneta = new Camioneta(
                    jsonTr.id,jsonTr.marca, jsonTr.modelo, jsonTr.precio,false);
                for(let k=0; k<arrayJSon.length;k++)
                {
                     if(arrayJSon[k].id == trModificar.firstElementChild.innerText)
                     {
                        arrayJSon[k] = objNuevo;
                     }
                }
                //arrayJSon[trModificar.firstElementChild.innerText] = objNuevo;
                localStorage.removeItem("key");
                localStorage.setItem("key",JSON.stringify(arrayJSon));

            }

          
            
        }
         //#endregion




        private static datosToGrilla(data: any, index:any): void{
            

            if(arrayJSon[index].es4x4 != null)
            {
                let objCamio:Camioneta = new Camioneta(data.id,data.marca,data.modelo,data.precio,data.cuatroXcuatro);
                let tr = objCamio.CrearElementoTr(index);
                tr.setAttribute("id",index);  
                $("#bodyTabla").append(tr);
            }
            else
            {
                let objAuto:Auto = new Auto(data.id,data.marca,data.modelo,data.precio,data.puertas);
                let tr = objAuto.CrearElementoTr(index);
                tr.setAttribute("id",index);  
                $("#bodyTabla").append(tr);
            }


           // console.log("empleado en la grilla sera" + objEmpleado.personaToJson());
            
         
        }


        public static CamposMostrados():void{
            let id: boolean = $("#checkId").prop('checked');
            let marca: boolean = $("#checkMarca").prop('checked');
            let modelo: boolean = $("#checkModelo").prop('checked');
            let precio: boolean = $("#checkPrecio").prop('checked');
           
           // let acumulador:JSON;
            let acumulador ={
                "id":false,
                "marca":false,
                "modelo":false,
                "precio":false,
                }
            if(id){acumulador.id = true};
            if(marca){acumulador.marca=true};
            if(modelo){acumulador.modelo=true};
            if(precio){acumulador.precio=true};
            let listaTR:any = $("#bodyTabla").children("TR");
            let obj = Manejadora.listaTrToJson(listaTR);
            //console.log(obj);
            //console.log(listaTR);
                                
            // let listaNuevaTD:any = listaTR.map(function(item:any){
            //     console.log(item);
            //     // item.map(function(td:any){
            //     //     console.log(td);
            //    // });
            // });
            $("#bodyTabla").html("");
            let listaNuevaTD:any = obj.map(function callback(currentValue:any, index:any, array:JSON) {
                console.log(currentValue.id);
                if(currentValue.id!= null)
                {
                   
                    let tr = Manejadora.CrearElementoTrUniversal(currentValue,acumulador);
                    tr.setAttribute("id",currentValue.id);  
                   $("#bodyTabla").append(tr);
                }
             

                // Elemento devuelto de nuevo_array
            });                
            
        }

//         private static GetTr():void{
//             let tr = $(this).parent().parent();
//             console.log("dos");
//             //Manejadora.Eliminar()  

//         }

        public static listaTrToJson(listaTr:any)
        {
            let actualJson:any = new Array();
            if(listaTr!=null)
            {
                
                
                for(let i=0;i<listaTr.length;i++)
                {
                    var ObjJson ={
                        "id":listaTr[i].cells.id.innerText,
                        "marca":listaTr[i].cells.marca.innerText,
                        "modelo":listaTr[i].cells.modelo.innerText,
                        "precio":listaTr[i].cells.precio.innerText,

                        }
                        actualJson.push(ObjJson);
                }
                
                return actualJson;
            }
            return null;
        }
//         public static pruebaPromedio()
//         {
//             $("#myModal").modal('show');

//         }

// //#region ns

// //#endregion

public static CrearElementoTrUniversal(valorJson:any,acumulador:any):HTMLTableRowElement{
    let tr:HTMLTableRowElement = document.createElement("tr");
    console.log(Object.keys(valorJson).length)
    if(acumulador.id!=false)
    {
        console.log("hay id");
        let tdId = this.CrearElementoTd(String(valorJson.id), "id");
        tr.appendChild(tdId);  
    }
    if(acumulador.marca!=false)
    {
        let tdMarca= this.CrearElementoTd(valorJson.marca, "marca");
        tr.appendChild(tdMarca);
       // console.log("hay marca");
    }
    if(acumulador.modelo!=false)
    {
        console.log("hay modelo");
    }
    if(acumulador.precio!=false)
    {
        console.log("hay precio");
    }

 
    
    //let tdId = this.CrearElementoTd("", "id");
//     let tdId = this.CrearElementoTd(String(this.id), "id");                
//    
//     let tdModelo = this.CrearElementoTd(this.modelo, "modelo"); 
//     let tdPrecio = this.CrearElementoTd(String(this.precio), "precio"); 
//    // let tdCuatroxCuatro = this.CrearElementoTd(String(this.cuatroXcuatro), "cuatroXcuatro");     
//     let tdAccion = this.CrearElementoTdAccion(index);   
    
//    // tr.appendChild(tdId);  
//     tr.appendChild(tdId);  
//     tr.appendChild(tdMarca);
//     tr.appendChild(tdModelo);                                              
//     tr.appendChild(tdPrecio);      
//    // tr.appendChild(tdCuatroxCuatro);
//     tr.appendChild(tdAccion);
                  
    return tr;
}

public static CrearElementoTd(dato:string, key:string):HTMLTableCellElement{
    let td:HTMLTableCellElement = document.createElement("td");
    td.setAttribute("name", key);
    if(key == "id"){
        //td.hidden = true;
    }            

    td.innerHTML = dato;

    return td;
}

    //#region hiddens
        public static OcultarBtnMod(valor:any)
        {
             $("#btnModificar").attr("hidden",valor);
        }   

        public static OcultarBtnGuardar(valor:any)
        {
             $("#altaVehiculo").attr("hidden",valor);
        }   
//#endregion



     }
}