"use strict";
var parcial;
(function (parcial) {
    var vehiculo = /** @class */ (function () {
        function vehiculo(id, marca, modelo, precio) {
            this.id = id;
            this.marca = marca;
            this.modelo = modelo;
            this.precio = precio;
        }
        vehiculo.prototype.personaToJson = function () {
            return JSON.stringify(this);
        };
        return vehiculo;
    }());
    parcial.vehiculo = vehiculo;
})(parcial || (parcial = {}));
