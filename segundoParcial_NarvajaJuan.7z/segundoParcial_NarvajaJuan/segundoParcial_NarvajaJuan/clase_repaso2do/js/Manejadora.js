"use strict";
var parcial;
(function (parcial) {
    $(document).ready(function () {
        // $("#btnCancelar").click(Manejadora.limpiarFormulario);
        // $("#btnGuardar").click(Manejadora.agregarEmpleado);
        // $("#mostrar").click(Manejadora.mostrarEmpleados);
        // $("#promedio").click(Manejadora.pruebaPromedio);
        // $("#btnModificar").click(function(event)
        // {
        //     Manejadora.modificarEnGrilla();
        //  });
        //  $("#filtrarPromedio").click(Manejadora.filtrarPromedio);
        $("#btnModificar").click(function (event) {
            Manejadora.modificarEnGrilla();
        });
        $("#sacarProm").click(Manejadora.sacarPromedio);
        $("#alta").click(Manejadora.mostrarFormulario);
        $("#limpiar").click(Manejadora.limpiarLS);
        $("#mostrar").click(Manejadora.mostrarVehiculos);
        $("#altaVehiculo").click(Manejadora.cargarVehiculo);
        $("#tipoV").change(Manejadora.validaTipoVehiculo);
        $("#TipoS").change(Manejadora.mostrarVehiculosSelecc);
        $("#checkId").change(Manejadora.CamposMostrados);
        $("#checkMarca").change(Manejadora.CamposMostrados);
        $("#checkModelo").change(Manejadora.CamposMostrados);
        $("#checkPrecio").change(Manejadora.CamposMostrados);
    });
    var arrayJSon = new Array();
    //var arrayAutos:any = new Array();
    //var arrayCamionetas:any = new Array();
    // var arrayEmpleados: Empleado[] = new Array();
    var guardado = localStorage.getItem("key");
    //console.log("se ejecuto el arrayEmpleados");
    if (guardado != null) {
        arrayJSon = JSON.parse(guardado);
    }
    var trModificar;
    var Manejadora = /** @class */ (function () {
        function Manejadora() {
        }
        Manejadora.mostrarFormulario = function () {
            //$("#formAlta").attr("hidden",false);
            Manejadora.OcultarBtnMod(true);
            Manejadora.OcultarBtnGuardar(false);
            $("#tipoV").attr("hidden", false);
            $("#ptipoV").attr("hidden", false);
            $("#formAlta").modal('show');
        };
        Manejadora.cargarVehiculo = function () {
            //console.log("entra");
            var id = Number($("#id").val());
            var marca = String($("#marca").val());
            var modelo = String($("#modelo").val());
            var precio = Number($("#precio").val());
            var tipoV = $("#tipoV").val();
            //console.log(tipoV);
            // let turno:string = String($("#turno").val());
            var idA = Manejadora.obtenerultimoId() + 1;
            //$("#id").val("esto");
            console.log(idA);
            if (marca != "" && modelo != "" && precio != 0) {
                if (tipoV == "Camioneta") {
                    var es4x4 = $("#ch4x4").is(":checked");
                    var unCamio = new parcial.Camioneta(idA, marca, modelo, precio, es4x4);
                    arrayJSon.push(unCamio);
                    console.log(arrayJSon);
                }
                else if (tipoV == "Auto") {
                    var puertas = Number($("#puertas").val());
                    var unAuto = new parcial.Auto(idA, marca, modelo, precio, puertas);
                    arrayJSon.push(unAuto);
                    console.log(arrayJSon);
                }
                localStorage.removeItem("key");
                localStorage.setItem("key", JSON.stringify(arrayJSon));
            }
            // let legajo 
            //$("#formAlta").attr("hidden",false);
            Manejadora.limpiarFormulario();
        };
        Manejadora.limpiarFormulario = function () {
            $("#id").val("");
            $("#marca").val("");
            $("#modelo").val("");
            $("#precio").val("");
            $("#puertas").val("");
        };
        Manejadora.obtenerultimoId = function () {
            if (arrayJSon.length != 0) {
                var i = arrayJSon.reduce(function (valorAnterior, valorActual, indice, vector) {
                    return valorActual;
                });
                return i.id;
                //      });
                //  return arrayJSon.length;
            }
            else {
                return 0;
            }
            //console.log(i);
        };
        Manejadora.validaTipoVehiculo = function () {
            //console.log("te meustro las cosas de la camioneta");
            var bool = false;
            var val = $("#tipoV").val();
            if (val == "Camioneta") {
                $("#es4x4").attr("hidden", bool);
                $("#puertas").attr("hidden", !(bool));
                // console.log("te meustro las cosas de la camioneta");
            }
            else if (val == "Auto") {
                $("#puertas").attr("hidden", bool);
                $("#es4x4").attr("hidden", !(bool));
            }
        };
        Manejadora.mostrarVehiculos = function () {
            console.log(arrayJSon.length);
            $("#bodyTabla").html("");
            //for(let i=0; i<arrayEmpleados.length; i++)
            for (var i = 0; i < arrayJSon.length; i++) {
                // let data = JSON.parse(String(arrayEmpleados.indexOf()));              
                var data = arrayJSon[i];
                Manejadora.datosToGrilla(data, i);
            }
            // arrayEmpleados;
            $("[name='accionModificar']").click(function (event) {
                var id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
                Manejadora.modificar(id);
            });
            $("[name='accionBorrar']").click(function (event) {
                var id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
                //console.log(id);
                Manejadora.eliminar(id);
            });
        };
        //  public static mostrarVehiculosSelecc():void
        //  {
        //      //console.log(arrayJSon.length);
        //      $("#bodyTabla").html("");
        //      //arrayCamionetas.lenght = 0;
        //      let val = $("#TipoS").val();
        //      //for(let i=0; i<arrayEmpleados.length; i++)
        //      for(let i=0; i<arrayJSon.length; i++)
        //      {
        //          if(arrayJSon[i].cuatroXcuatro != null && val == "Camioneta" )
        //          {
        //             let data = arrayJSon[i];            
        //             Manejadora.datosToGrilla(data, i);
        //             //arrayCamionetas.push(arrayJSon[i]);
        //          }
        //          else if (arrayJSon[i].puertas != null && val == "Auto" )
        //          {
        //             let data = arrayJSon[i];            
        //             Manejadora.datosToGrilla(data, i);
        //             //arrayAutos.push(arrayJSon[i]);
        //          }
        //          // let data = JSON.parse(String(arrayEmpleados.indexOf()));              
        //      }   
        //      $("[name='accionBorrar']").click(function(event)
        //      {
        //       let id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
        //       console.log(id);
        //       Manejadora.eliminar(id);
        //       });   
        //     }
        Manejadora.mostrarVehiculosSelecc = function () {
            //console.log(arrayJSon.length);
            $("#bodyTabla").html("");
            //arrayCamionetas.lenght = 0;
            var val = $("#TipoS").val();
            var arrayCamios = arrayJSon.filter(function (obj) {
                return obj.cuatroXcuatro != undefined;
            });
            var arrayAutos = arrayJSon.filter(function (obj) {
                return obj.puertas != undefined;
            });
            //console.log(arrayAutos);
            var arrayGeneral;
            if (val == "Camioneta") {
                arrayGeneral = arrayCamios;
            }
            else {
                arrayGeneral = arrayAutos;
            }
            for (var i = 0; i < arrayGeneral.length; i++) {
                var data = arrayGeneral[i];
                Manejadora.datosToGrilla(data, i);
                //arrayCamionetas.push(arrayJSon[i]);
            }
            // let data = JSON.parse(String(arrayEmpleados.indexOf()));                 
            $("[name='accionBorrar']").click(function (event) {
                var id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
                console.log(id);
                Manejadora.eliminar(id);
            });
            $("[name='accionModificar']").click(function (event) {
                var id = event.delegateTarget.parentElement.parentElement.attributes.id.value;
                Manejadora.modificar(id);
            });
        };
        Manejadora.sacarPromedio = function () {
            var sumatoria = arrayJSon.reduce(function (suma, item) {
                return suma += item.precio;
            }, 0);
            console.log(sumatoria);
            if (sumatoria != 0) {
                sumatoria = sumatoria / arrayJSon.length;
            }
            console.log(sumatoria);
            $("#promedioC").val(sumatoria);
        };
        Manejadora.limpiarLS = function () {
            localStorage.clear();
        };
        //         //#region  eliminar
        Manejadora.eliminar = function (i) {
            var hijos = $("#" + i);
            console.log(arrayJSon[i]);
            if (arrayJSon[i] != undefined) {
                if (hijos != null) {
                    console.log("el id del tr es" + hijos[0].id);
                    for (var j = 0; j < hijos[0].parentNode.children.length; j++) {
                        if (i == Number(hijos[0].parentNode.children[j].id)) {
                            arrayJSon.splice(i, 1);
                            localStorage.removeItem("key");
                            localStorage.setItem("key", JSON.stringify(arrayJSon));
                        }
                    }
                    Manejadora.mostrarVehiculos();
                }
            }
            //#endregion
        };
        //#region modificar   
        Manejadora.modificar = function (i) {
            Manejadora.mostrarFormulario();
            Manejadora.OcultarBtnMod(false);
            Manejadora.OcultarBtnGuardar(true);
            $("#tipoV").attr("hidden", "true");
            $("#ptipoV").attr("hidden", "true");
            var hijos = $("#" + i);
            if (hijos != null) {
                console.log("el id del tr es" + hijos[0].id);
                for (var j = 0; j < hijos[0].parentNode.children.length; j++) {
                    if (i == Number(hijos[0].parentNode.children[j].id)) {
                        trModificar = hijos[0].parentNode.children[j];
                        //console.log(trModificar);
                        var trJson = Manejadora.trToJson(hijos[0].parentNode.children[j]);
                        if (trJson != null) {
                            $("#marca").val(trJson.marca);
                            $("#modelo").val(trJson.modelo);
                            $("#precio").val(trJson.precio);
                            // $("#legajo").val(trJson.legajo);
                            // $("#turno").val(trJson.horario);
                        }
                    }
                }
            }
        };
        Manejadora.trToJson = function (tr) {
            if (tr != null) {
                var ObjJson = {
                    "id": tr.cells.id.innerText,
                    "marca": tr.cells.marca.innerText,
                    "modelo": tr.cells.modelo.innerText,
                    "precio": tr.cells.precio.innerText
                };
                return ObjJson;
            }
            return null;
        };
        Manejadora.modificarEnGrilla = function () {
            console.log(trModificar);
            trModificar.cells.marca.innerText = $("#marca").val();
            trModificar.cells.modelo.innerText = $("#modelo").val();
            trModificar.cells.precio.innerText = $("#precio").val();
            // trModificar.cells.legajo.innerText = $("#legajo").val();
            // trModificar.cells.horario.innerText = $("#turno").val();
            var objJson = Manejadora.trToJson(trModificar);
            Manejadora.limpiarFormulario();
            console.log("hicist click y lo tomo");
            var jsonTr = Manejadora.trToJson(trModificar);
            if (jsonTr != null) {
                var objNuevo = new parcial.Camioneta(jsonTr.id, jsonTr.marca, jsonTr.modelo, jsonTr.precio, false);
                for (var k = 0; k < arrayJSon.length; k++) {
                    if (arrayJSon[k].id == trModificar.firstElementChild.innerText) {
                        arrayJSon[k] = objNuevo;
                    }
                }
                //arrayJSon[trModificar.firstElementChild.innerText] = objNuevo;
                localStorage.removeItem("key");
                localStorage.setItem("key", JSON.stringify(arrayJSon));
            }
        };
        //#endregion
        Manejadora.datosToGrilla = function (data, index) {
            if (arrayJSon[index].es4x4 != null) {
                var objCamio = new parcial.Camioneta(data.id, data.marca, data.modelo, data.precio, data.cuatroXcuatro);
                var tr = objCamio.CrearElementoTr(index);
                tr.setAttribute("id", index);
                $("#bodyTabla").append(tr);
            }
            else {
                var objAuto = new parcial.Auto(data.id, data.marca, data.modelo, data.precio, data.puertas);
                var tr = objAuto.CrearElementoTr(index);
                tr.setAttribute("id", index);
                $("#bodyTabla").append(tr);
            }
            // console.log("empleado en la grilla sera" + objEmpleado.personaToJson());
        };
        Manejadora.CamposMostrados = function () {
            var id = $("#checkId").prop('checked');
            var marca = $("#checkMarca").prop('checked');
            var modelo = $("#checkModelo").prop('checked');
            var precio = $("#checkPrecio").prop('checked');
            // let acumulador:JSON;
            var acumulador = {
                "id": false,
                "marca": false,
                "modelo": false,
                "precio": false,
            };
            if (id) {
                acumulador.id = true;
            }
            ;
            if (marca) {
                acumulador.marca = true;
            }
            ;
            if (modelo) {
                acumulador.modelo = true;
            }
            ;
            if (precio) {
                acumulador.precio = true;
            }
            ;
            var listaTR = $("#bodyTabla").children("TR");
            var obj = Manejadora.listaTrToJson(listaTR);
            //console.log(obj);
            //console.log(listaTR);
            // let listaNuevaTD:any = listaTR.map(function(item:any){
            //     console.log(item);
            //     // item.map(function(td:any){
            //     //     console.log(td);
            //    // });
            // });
            $("#bodyTabla").html("");
            var listaNuevaTD = obj.map(function callback(currentValue, index, array) {
                console.log(currentValue.id);
                if (currentValue.id != null) {
                    var tr = Manejadora.CrearElementoTrUniversal(currentValue, acumulador);
                    tr.setAttribute("id", currentValue.id);
                    $("#bodyTabla").append(tr);
                }
                // Elemento devuelto de nuevo_array
            });
        };
        //         private static GetTr():void{
        //             let tr = $(this).parent().parent();
        //             console.log("dos");
        //             //Manejadora.Eliminar()  
        //         }
        Manejadora.listaTrToJson = function (listaTr) {
            var actualJson = new Array();
            if (listaTr != null) {
                for (var i = 0; i < listaTr.length; i++) {
                    var ObjJson = {
                        "id": listaTr[i].cells.id.innerText,
                        "marca": listaTr[i].cells.marca.innerText,
                        "modelo": listaTr[i].cells.modelo.innerText,
                        "precio": listaTr[i].cells.precio.innerText,
                    };
                    actualJson.push(ObjJson);
                }
                return actualJson;
            }
            return null;
        };
        //         public static pruebaPromedio()
        //         {
        //             $("#myModal").modal('show');
        //         }
        // //#region ns
        // //#endregion
        Manejadora.CrearElementoTrUniversal = function (valorJson, acumulador) {
            var tr = document.createElement("tr");
            console.log(Object.keys(valorJson).length);
            if (acumulador.id != false) {
                console.log("hay id");
                var tdId = this.CrearElementoTd(String(valorJson.id), "id");
                tr.appendChild(tdId);
            }
            if (acumulador.marca != false) {
                var tdMarca = this.CrearElementoTd(valorJson.marca, "marca");
                tr.appendChild(tdMarca);
                // console.log("hay marca");
            }
            if (acumulador.modelo != false) {
                console.log("hay modelo");
            }
            if (acumulador.precio != false) {
                console.log("hay precio");
            }
            //let tdId = this.CrearElementoTd("", "id");
            //     let tdId = this.CrearElementoTd(String(this.id), "id");                
            //    
            //     let tdModelo = this.CrearElementoTd(this.modelo, "modelo"); 
            //     let tdPrecio = this.CrearElementoTd(String(this.precio), "precio"); 
            //    // let tdCuatroxCuatro = this.CrearElementoTd(String(this.cuatroXcuatro), "cuatroXcuatro");     
            //     let tdAccion = this.CrearElementoTdAccion(index);   
            //    // tr.appendChild(tdId);  
            //     tr.appendChild(tdId);  
            //     tr.appendChild(tdMarca);
            //     tr.appendChild(tdModelo);                                              
            //     tr.appendChild(tdPrecio);      
            //    // tr.appendChild(tdCuatroxCuatro);
            //     tr.appendChild(tdAccion);
            return tr;
        };
        Manejadora.CrearElementoTd = function (dato, key) {
            var td = document.createElement("td");
            td.setAttribute("name", key);
            if (key == "id") {
                //td.hidden = true;
            }
            td.innerHTML = dato;
            return td;
        };
        //#region hiddens
        Manejadora.OcultarBtnMod = function (valor) {
            $("#btnModificar").attr("hidden", valor);
        };
        Manejadora.OcultarBtnGuardar = function (valor) {
            $("#altaVehiculo").attr("hidden", valor);
        };
        return Manejadora;
    }());
    parcial.Manejadora = Manejadora;
})(parcial || (parcial = {}));
